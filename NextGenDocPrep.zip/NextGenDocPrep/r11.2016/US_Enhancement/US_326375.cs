﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r11._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_326375 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private void LoadTemplateOrCreateNewWithoutLogin(string templateName, string templateDesc, string templateType)
        {
            
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

       

        

        [TestMethod]
        public void ITR_r10_2016_US_326375_TC_878644_No_1()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is able to delete multiple documents of same document type from Document Repository Screen";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");       

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen to add 1st document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();              
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1,7, TableAction.GetText).Message;
                docName1 = docName1.Trim();
                Support.AreEqual(docName1, EGtempnameanddesc, "Document exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen to add 2nd document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 7, TableAction.GetText).Message;
                docName2 = docName2.Trim();
                Support.AreEqual(docName2, EGtempnameanddesc, "Document exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen to add 3rd document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(3, 7, TableAction.GetText).Message;
                docName3 = docName3.Trim();
                Support.AreEqual(docName3, EGtempnameanddesc, "Document exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen to add 4th document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName4 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(4, 7, TableAction.GetText).Message;
                docName4 = docName4.Trim();
                Support.AreEqual(docName4, EGtempnameanddesc, "Document exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";
             
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

                
                Playback.Wait(7000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify the documents got deleted from the documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "All Doc Removed");
                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878645_No_2()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is able to delete multiple documents of different document type from Document Repository Screen";

               
                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;

                string FOtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                FOtempnameanddesc = "FO-" + FOtempnameanddesc;

                string LRDtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                LRDtempnameanddesc = "LD-" + LRDtempnameanddesc;
                                               

                LoadTemplateOrCreateNew(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");

                LoadTemplateOrCreateNewWithoutLogin(FOtempnameanddesc, FOtempnameanddesc, "Form");

                LoadTemplateOrCreateNewWithoutLogin(LRDtempnameanddesc, LRDtempnameanddesc, "Legal/Recordable Doc");
                
                Reports.TestStep = "FAST IIS Login";

                #region File Side Login 
                Reports.TestStep = "Login to IIS as Superuser";

                var url = AutoConfig.FASTHomeURL;

                string url1 = url.ToString().ToUpper().Trim();

                if (url1.Contains("FEVA"))
                {
                    var credentials = new Credentials() { UserName = "feva-sa-su", Password = "superuser" };
                    FASTLogin.Login(url, credentials, true);
                }

                if (url1.Contains("FINT"))
                {
                    var credentials1 = new Credentials() { UserName = "faqa-sa-su", Password = "Superuser3" };
                    FASTLogin.Login(url, credentials1, true);
                }
                #endregion

                FAST_OpenRegionOrOffice(officeId);

                #region Create File
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");

                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

              
                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Form document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Form type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(FOtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, FOtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Form exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Legal/Recordable Doc document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Legal/Recordable Doc type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Legal/Recordable Doc");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LRDtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LRDtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName4 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString();
                docName4 = docName4.Trim();
                Support.AreEqual("True", docName4, "Legal/Recordable Doc exists on the Search Result Table");
                      
          
                Reports.TestStep = "Upload Document";
                               
               
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                          
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
            
               
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);                       
                 
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                           
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Creating a CPL Document";
                FastDriver.ClosingProtectionLetter.Open();
                FastDriver.ClosingProtectionLetter.WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.LetterType.FASelectItem("Standard");
                FastDriver.ClosingProtectionLetter.UnderWriters.FASelectItem("First American Title Insurance Company");
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.LenderDetailsPhone.FASetText("1111111111");
                FastDriver.ClosingProtectionLetter.LenderDetailsFax.FASetText("2222222222");
                FastDriver.ClosingProtectionLetter.LenderDetailsCellPhone.FASetText("3333333333");
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(30000);


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify that CPL is created";
                var CPLDoc = FastDriver.NextGenDocumentRepository.WaitForDocument("Closing Protection Letter - LENDER", "CPL");
                Support.AreEqual("True", CPLDoc.ToString(), "Document exists on the table");

                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EItempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

               
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n","").Replace("\t","").Trim();
                Support.AreEqual(errormsg, "DO YOU WISH TO VOID THE SELECTED CPL(S) CLOSING PROTECTION LETTER - LENDER ?", "Error Message Verified");

            
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify the documents got deleted from the documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Closing Protection Letter").ToString(), "CPL- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Deleted");
                
                                
                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName22 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName22 = docName22.Trim();
                Support.AreEqual("True", docName22, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Form document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Form type template using template search criteria";
               
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(FOtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, FOtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName33 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString();
                docName33 = docName33.Trim();
                Support.AreEqual("True", docName33, "Form exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Legal/Recordable Doc document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Legal/Recordable Doc type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Legal/Recordable Doc");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LRDtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LRDtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName44 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString();
                docName44 = docName44.Trim();
                Support.AreEqual("True", docName44, "Legal/Recordable Doc exists on the Search Result Table");


                Reports.TestStep = "Upload Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath1 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath1);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus1 = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus1.ToString(), "Document exists on the table");


                Reports.TestStep = "Creating a CPL Document";
                FastDriver.ClosingProtectionLetter.Open();
                FastDriver.ClosingProtectionLetter.WaitForScreenToLoad();
                FastDriver.ClosingProtectionLetter.LetterType.FASelectItem("Standard");
                FastDriver.ClosingProtectionLetter.UnderWriters.FASelectItem("First American Title Insurance Company");
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ClosingProtectionLetter.LenderDetailsPhone.FASetText("1111111111");
                FastDriver.ClosingProtectionLetter.LenderDetailsFax.FASetText("2222222222");
                FastDriver.ClosingProtectionLetter.LenderDetailsCellPhone.FASetText("3333333333");
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                Playback.Wait(15000);


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EItempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

               
                Playback.Wait(5000);

                string errormsg2 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                errormsg2 = errormsg2.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg2, "DO YOU WISH TO VOID THE SELECTED CPL(S) CLOSING PROTECTION LETTER - LENDER ?", "Error Message Verified");

            
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify all the documents got deleted from the documents list except CPL Documents";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Closing Protection Letter").ToString(), "CPL- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Deleted");
                


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r10_2016_US_326375_TC_878650_No_3()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents having multiple finalized document in Document Repository Screen";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;

                string FOtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                FOtempnameanddesc = "FO-" + FOtempnameanddesc;

                string LRDtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                LRDtempnameanddesc = "LD-" + LRDtempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");

                LoadTemplateOrCreateNewWithoutLogin(FOtempnameanddesc, FOtempnameanddesc, "Form");

                LoadTemplateOrCreateNewWithoutLogin(LRDtempnameanddesc, LRDtempnameanddesc, "Legal/Recordable Doc");

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Form document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Form type template using template search criteria";
             

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(FOtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, FOtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Form exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Legal/Recordable Doc document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Legal/Recordable Doc type template using template search criteria";
              
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Legal/Recordable Doc");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LRDtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LRDtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName4 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString();
                docName4 = docName4.Trim();
                Support.AreEqual("True", docName4, "Legal/Recordable Doc exists on the Search Result Table");
                
               
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Finalized Endorsement/Guarantee and Escrow Instruction in File Documents Table grid";


                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Finalize.JSClick();
                Playback.Wait(10000);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EItempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Finalize.JSClick();
                Playback.Wait(10000);            
            
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);
                
                Reports.TestStep = "Validate the error message that finalized documents cannot be removed";
                
                string errormsg= FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) IS/ARE IN FINALIZED STATUS, CANNOT BE REMOVED. DOCUMENT NAME : "+EGtempnameanddesc+","+EItempnameanddesc+".", "Error Message Verified");
                               
                Playback.Wait(7000);

                Reports.TestStep = "Verify the  unfinalized documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement/Guarantee- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Deleted");


                Reports.TestStep = "Navigate to Document Repository Screen to add Form document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the  unfinalized documents got deleted from the documents list";
                
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement/Guarantee- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Deleted");

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Form type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(FOtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, FOtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName33 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString();
                docName33 = docName33.Trim();
                Support.AreEqual("True", docName33, "Form exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Legal/Recordable Doc document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Legal/Recordable Doc type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Legal/Recordable Doc");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LRDtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LRDtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName44 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString();
                docName44 = docName44.Trim();
                Support.AreEqual("True", docName44, "Legal/Recordable Doc exists on the Search Result Table");

                Reports.TestStep = "Filter only Finalized Documents";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();
                FastDriver.NextGenDocumentRepository.FinalizedFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StatusFilterOK.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";
              
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                              
                Playback.Wait(5000);
                
                Reports.TestStep = "Validate the error message that finalized documents cannot be removed";
                
                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "DOCUMENT(S) IS/ARE IN FINALIZED STATUS, CANNOT BE REMOVED. DOCUMENT NAME : " + EGtempnameanddesc + "," + EItempnameanddesc + ".", "Error Message Verified");

                Reports.TestStep = "Remove filters";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearStatusFilter();

                Playback.Wait(3000);

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement/Guarantee- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Exists");
                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r10_2016_US_326375_TC_878652_No_4()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents having multiple Title Report document associated with policy";

                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;

                string TR2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                TR2tempnameanddesc = "TR2-" + TR2tempnameanddesc;

                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;


                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(TR2tempnameanddesc, TR2tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Title Reports exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR2tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR2tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Title Reports exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Lender Policy type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate policy with first title report";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(1);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Lender Policy exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Owner Policy type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, OPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(5000);
                Reports.TestStep = "Associate policy with second title report";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(2);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName4 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString();
                docName4 = docName4.Trim();
                Support.AreEqual("True", docName4, "Owner Policy exists on the Search Result Table");

          
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TR1tempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);
                
                Reports.TestStep = "Validate the error message that title report documents cannot be removed";


                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "TITLE REPORT(S) " + TR1tempnameanddesc + "," + TR2tempnameanddesc + " IS/ARE ASSOCIATED TO A POLICY AND CANNOT BE REMOVED.", "Error Message Verified");
                               
                Playback.Wait(7000);
                
                Reports.TestStep = "Verify the  non title reports documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Deleted");
                


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the  non title reports documents got deleted from the documents list";
                
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Deleted");

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Lender Policy type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate policy with first title report";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(1);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName33 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString();
                docName33 = docName33.Trim();
                Support.AreEqual("True", docName33, "Lender Policy exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Owner Policy type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, OPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(5000);
                Reports.TestStep = "Associate policy with second title report";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(2);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName44 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString();
                docName44 = docName44.Trim();
                Support.AreEqual("True", docName44, "Owner Policy exists on the Search Result Table");
                

                Reports.TestStep = "Filter only Title Reports Documents";

                FastDriver.NextGenDocumentRepository.FilterTitleReport();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TR1tempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that title report documents cannot be removed";


                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "TITLE REPORT(S) " + TR1tempnameanddesc + "," + TR2tempnameanddesc + " IS/ARE ASSOCIATED TO A POLICY AND CANNOT BE REMOVED.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Exists");
                                
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r10_2016_US_326375_TC_878655_No_5()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents having multiple Policy document associated with endorsement";

                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;
                
                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;


                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");
                
                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");

                LoadTemplateOrCreateNewWithoutLogin(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Title Reports exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Lender Policy type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
             
                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Lender Policy exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Owner Policy type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, OPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Owner Policy exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate endorsement with first policy";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(1);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName4 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName4 = docName4.Trim();
                Support.AreEqual("True", docName4, "Endorsement/Guarantee exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate endorsement with second policy";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(2);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName5 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName5 = docName5.Trim();
                Support.AreEqual("True", docName5, "Endorsement/Guarantee exists on the Search Result Table");
                

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Select all the documents except Title Report from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();

                UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
                Playback.Wait(500); // need this
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TR1tempnameanddesc, "Name", TableAction.Click);
                
                UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key
                                
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", LPtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);
                
                Reports.TestStep = "Validate the error message that policy documents cannot be removed";
                
                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "POLICY DOCUMENT(S) " + LPtempnameanddesc + "," + OPtempnameanddesc + " IS/ARE ASSOCIATED TO ONE OR MORE ENDORSEMENT/GUARANTEE DOCUMENTS AND CANNOT BE REMOVED.", "Error Message Verified");
                             
                Playback.Wait(7000);

                Reports.TestStep = "Verify Endorsement documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify Endorsement documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate endorsement with first policy";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(1);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName44 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName44 = docName44.Trim();
                Support.AreEqual("True", docName44, "Endorsement/Guarantee exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(5000);
                Reports.TestStep = "Associate endorsement with second policy";

                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(2);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName55 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName55 = docName55.Trim();
                Support.AreEqual("True", docName55, "Endorsement/Guarantee exists on the Search Result Table");
                

                Reports.TestStep = "Filter only Policy Documents";

                FastDriver.NextGenDocumentRepository.FilterPolicyDoc();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", LPtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                            
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that policy documents cannot be removed";


                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "POLICY DOCUMENT(S) " + LPtempnameanddesc + "," + OPtempnameanddesc + " IS/ARE ASSOCIATED TO ONE OR MORE ENDORSEMENT/GUARANTEE DOCUMENTS AND CANNOT BE REMOVED.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";
                
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Exists");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878657_No_6()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete multiple published document";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;
                            

                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");
                
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Escrow Instruction exists on the Search Result Table");
                
             
                Reports.TestStep = "Upload first image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                

                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");

                Reports.TestStep = "Publish the first document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPublishQueue.JSClick();
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.PublishDocTable.PerformTableAction(3, "Business Source", 1, TableAction.Click);

                FastDriver.NextGenDocumentRepository.PublishDocument_Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);
                

                Reports.TestStep = "Publish the second document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "PO-Commission Instructions PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPublishQueue.JSClick();
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.PublishDocTable.PerformTableAction(3, "Business Source", 1, TableAction.Click);

                FastDriver.NextGenDocumentRepository.PublishDocument_Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                              
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT IS/ARE PUBLISHED OR FLAGGED AND CANNOT BE REMOVED.", "Error Message Verified");
                            
                Playback.Wait(7000);
                
                Reports.TestStep = "Verify other documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Deleted");



                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify other documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Deleted");

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName11 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName11 = docName11.Trim();
                Support.AreEqual("True", docName11, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName22 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName22 = docName22.Trim();
                Support.AreEqual("True", docName22, "Escrow Instruction exists on the Search Result Table");
                


                Reports.TestStep = "Filter only Image Documents";

                FastDriver.NextGenDocumentRepository.FilterImageDoc();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT IS/ARE PUBLISHED OR FLAGGED AND CANNOT BE REMOVED.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Exists");

                
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878661_No_7()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents copied through Starter- Ref";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;
                                

                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");
                               

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " First File created successfully");

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string firstfile= FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");
                

                Reports.TestStep = "Upload first image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");


                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " Second File created successfully");

                Reports.TestStep = "Navigate to Starter/Ref. Screen";
                FastDriver.StarterReference.Open();
                FastDriver.StarterReference.WaitForScreenToLoad();

                Reports.TestStep = "Search first file and copy docs";
                FastDriver.StarterReference.StarterFileNumber.FASetText(firstfile);
                FastDriver.StarterReference.CopyDocument.FAClick();
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
               
                Playback.Wait(30000);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                var sr1 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", sr1.ToString(), "Document exists on the table");
                var sr2 = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", sr2.ToString(), "Document exists on the table");
                var sr3 = FastDriver.NextGenDocumentRepository.WaitForDocument(EGtempnameanddesc, "Endorsement/Guarantee");
                Support.AreEqual("True", sr3.ToString(), "Document exists on the table");
                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT COPIED USING STARTER REF. AND IS IN EITHER THE SOURCE FILE OR TARGET FILE AND CANNOT BE REMOVED.", "Error Message Verified");
                               
                Playback.Wait(7000);

                Reports.TestStep = "Verify other documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify other documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878663_No_8()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents copied through Search Scope";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " First File created successfully");

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string firstfile = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Upload first image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");


                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " Second File created successfully");

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASetText(firstfile);
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentRepository.CopyAllButton.FAClick();
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                Playback.Wait(20000);
              
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                var sr1 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", sr1.ToString(), "Document exists on the table");
                var sr2 = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", sr2.ToString(), "Document exists on the table");
                var sr3 = FastDriver.NextGenDocumentRepository.WaitForDocument(EGtempnameanddesc, "Endorsement/Guarantee");
                Support.AreEqual("True", sr3.ToString(), "Document exists on the table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT COPIED USING STARTER REF. AND IS IN EITHER THE SOURCE FILE OR TARGET FILE AND CANNOT BE REMOVED.", "Error Message Verified");
                               
                Playback.Wait(7000);

                Reports.TestStep = "Verify other documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify other documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                Reports.TestStep = "Search for the first file";
                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.SearchFileByFileNumber(firstfile);
                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT COPIED USING STARTER REF. AND IS IN EITHER THE SOURCE FILE OR TARGET FILE AND CANNOT BE REMOVED.", "Error Message Verified");

                Playback.Wait(7000);

                Reports.TestStep = "Verify other documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify other documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878665_No_9()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete documents linked with wire disbursement";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " First File created successfully");
                                
                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Upload first image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");

                Reports.TestStep = "Add charges in HOA Screen";

                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                Playback.Wait(3000);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", 10.00, null, null, null, null);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                
                Reports.TestStep = "Add charges in HomeWarranty Screen";

                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HUDFLINSR1");
                Playback.Wait(5000);
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", 15.00, null, null, null, null);
                FastDriver.HomeWarrantyDetail.SaveAndReloadScreen();


                Reports.TestStep = "Associating Documents to the  first check from Active Disbursement Screen";


                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "10.00", 7, TableAction.Click);
                Playback.Wait(2000);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("1234");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("Test Bank");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("5678");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("5678");
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();



                Reports.TestStep = "Associating Documents to the  second check from Active Disbursement Screen";


                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "15.00", 7, TableAction.Click);
                Playback.Wait(2000);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("9876");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("Testing Bank");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("3582");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("3582");
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.SelectSecondWireInstruction();
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that linked documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT CANNOT BE REMOVED BECAUSE IT'S ATTACHED TO A CREATED, PENDING OR ISSUED WIRE DISBURSEMENT.PLEASE REMOVE FROM WIRE DISBURSEMENT BEFORE REMOVING THE DOCUMENT.", "Error Message Verified");
                               
                Playback.Wait(7000);

                Reports.TestStep = "Verify endorsement documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify endorsement documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
             

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName11 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName11 = docName11.Trim();
                Support.AreEqual("True", docName11, "Endorsement/Guarantee exists on the Search Result Table");
                

                Reports.TestStep = "Filter only Image Documents";

                FastDriver.NextGenDocumentRepository.FilterImageDoc();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that linked documents cannot be removed";

                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT CANNOT BE REMOVED BECAUSE IT'S ATTACHED TO A CREATED, PENDING OR ISSUED WIRE DISBURSEMENT.PLEASE REMOVE FROM WIRE DISBURSEMENT BEFORE REMOVING THE DOCUMENT.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Exists");
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r10_2016_US_326375_TC_878667_No_10()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete document having Agent Net Policy number";

                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;

                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;


                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");
                               
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                #region Create File
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
               
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");

                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
               try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
               FastDriver.FileHomepage.WaitForScreenToLoad();
                
                #endregion

                #region Create Loan Amount and Number
               FastDriver.NewLoan.Open();
               FastDriver.NewLoan.WaitForScreenToLoad();
               FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345");
               FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("67890");
               FastDriver.BottomFrame.Done();
               FastDriver.NewLoan.WaitForScreenToLoad();
               #endregion

               Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Title Reports exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Lender Policy type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(7000);
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Lender Policy exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Navigate to Request Policy Number Screen";
                FastDriver.RequestPolicyNumber.Open();
                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();

                Reports.TestStep = "Select Underwriter";
                FastDriver.RequestPolicyNumber.Underwriter.FASelectItem("First American Title Insurance Company");
                Playback.Wait(5000);

                Reports.TestStep = "Select Office";
                FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                Playback.Wait(1000);

                Reports.TestStep = "Select Product";
                FastDriver.RequestPolicyNumber.SelProduct.FAClick();
                FastDriver.RPNProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.RPNProductSelectionDlg.grdSTARSProptJacketSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Request for Policy Number";

                FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
                FastDriver.RequestPolicyNumber.Table.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.RequestPolicyNumber.RequestNumber.FAClick();

              
                Playback.Wait(15000);


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Editing the Lender Policy";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name",LPtempnameanddesc, "Name", TableAction.DoubleClick);
                Playback.Wait(10000);

                Reports.TestStep = "Save Policy with effective date";
                FastDriver.NextGenDocumentRepository.DocumentInfoTab1.FAClickAction();
                FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM-dd-yyyy"));
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();

                Playback.Wait(5000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                
                Reports.TestStep = "Editing the Lender Policy";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name",LPtempnameanddesc, "Name", TableAction.DoubleClick);
                Playback.Wait(10000);
                Reports.TestStep = "Click on Info";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentInfoTab1.FAClickAction();
                Playback.Wait(5000);
                Reports.TestStep = "Assign Policy Number to Lender Policy";

                FastDriver.NextGenDocumentRepository.AssignPolicyNum.FAClick();
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
               
                Playback.Wait(5000);


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Select all the documents except Title Report from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();

                UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
                Playback.Wait(500); // need this
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TR1tempnameanddesc, "Name", TableAction.Click);

                UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", LPtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();

                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that policy documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) " +LPtempnameanddesc +" HAS AN AGENTNET POLICY NUMBER. PLEASE VOID THE POLICY NUMBER FIRST, AND THEN YOU CAN REMOVE THE DOCUMENT.", "Error Message Verified");
                              
                Playback.Wait(7000);

                Reports.TestStep = "Verify Escrow Instruction documents got deleted from the documents list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Deleted");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify Escrow Instruction documents got deleted from the documents list";
                
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Deleted");



               Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName33 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName33 = docName33.Trim();
                Support.AreEqual("True", docName33, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Filter only Policy Documents";

                FastDriver.NextGenDocumentRepository.FilterPolicyDoc();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", LPtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();

              
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that policy documents cannot be removed";

                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "DOCUMENT(S) " +LPtempnameanddesc +" HAS AN AGENTNET POLICY NUMBER. PLEASE VOID THE POLICY NUMBER FIRST, AND THEN YOU CAN REMOVE THE DOCUMENT.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Reports- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Exists");



            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_878675_No_11()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify the sequence of error messages on removing documents from Document Repository Screen";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " First File created successfully");

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string firstfile = FastDriver.FileHomepage.GetFileNumber();
                
                Reports.TestStep = "Upload first image Document";
                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                            


                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), " Second File created successfully");
                
                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Finalized Endorsement/Guarantee and Escrow Instruction in File Documents Table grid";
                
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Finalize.JSClick();
                Playback.Wait(10000);

                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");


                Reports.TestStep = "Publish the second image document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "PO-Commission Instructions PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPublishQueue.JSClick();
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.PublishDocTable.PerformTableAction(3, "Business Source", 1, TableAction.Click);

                FastDriver.NextGenDocumentRepository.PublishDocument_Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);
                
                Reports.TestStep = "Upload third image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath3 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath3);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Evidence of Insurance", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus3 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Evidence of Insurance PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus3.ToString(), "Document exists on the table");
                

                Reports.TestStep = "Add the third image document to Inerface Queue";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "PO-Evidence of Insurance PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddInterfaceQueue.FAMouseOver();
                FastDriver.NextGenDocumentRepository.EP.Highlight();
                FastDriver.NextGenDocumentRepository.EP.FASetCheckbox(true);
                Playback.Wait(3000);

                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);


                Reports.TestStep = "Navigate to Starter/Ref. Screen";
                FastDriver.StarterReference.Open();
                FastDriver.StarterReference.WaitForScreenToLoad();

                Reports.TestStep = "Search first file and copy docs";
                FastDriver.StarterReference.StarterFileNumber.FASetText(firstfile);
                FastDriver.StarterReference.CopyDocument.FAClick();
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                
                Playback.Wait(30000);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                             
                var sr1 = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", sr1.ToString(), "Starter/Ref Document exists on the table");
          
                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name",EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                               
                Playback.Wait(5000);

                Reports.TestStep = "Validate the sequence of error message";
                
                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DOCUMENT(S) IS/ARE IN FINALIZED STATUS, CANNOT BE REMOVED. DOCUMENT NAME : " + EGtempnameanddesc +".", "Finalized Error Message Verified");

                string errormsg2 = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                errormsg2 = errormsg2.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg2, "DOCUMENT(S) PO-COMMISSION INSTRUCTIONS PDFDOCUMENT IS/ARE PUBLISHED OR FLAGGED AND CANNOT BE REMOVED.", " Published Error Message Verified");

                string errormsg3 = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                errormsg3 = errormsg3.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg3, "DOCUMENT(S) PO-EVIDENCE OF INSURANCE PDFDOCUMENT IS/ARE ADDED TO INTERFACE QUEUE AND CANNOT BE REMOVED.", " Interface Queue Error Message Verified");

                string errormsg4 = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                errormsg4 = errormsg4.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg4, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT COPIED USING STARTER REF. AND IS IN EITHER THE SOURCE FILE OR TARGET FILE AND CANNOT BE REMOVED.", "Starter Ref Error Message Verified");
                Playback.Wait(5000);
                Reports.TestStep = "Verify none of the documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Starter Ref. Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Published Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Evidence of Insurance PDFDocument").ToString(), "Queued Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), " Finalized Endorsement- Exists");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify none of the documents got deleted from the documents list";
                
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Starter Ref. Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Published Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Evidence of Insurance PDFDocument").ToString(), "Queued Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), " Finalized Endorsement- Exists");


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void ITR_r10_2016_US_326375_TC_884493_No_12()
        {
            try
            {

                Reports.TestDescription = "User Story: 326375- Verify user is not able to delete document added to Interface Queue";

                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Escrow Instruction exists on the Search Result Table");


                Reports.TestStep = "Upload first image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Upload second image Document";


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                Reports.TestStep = "Browse document";
                string filePath2 = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath2);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus2 = FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus2.ToString(), "Document exists on the table");

                Reports.TestStep = "Add the first document to Inerface Queue";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddInterfaceQueue.FAMouseOver();
                FastDriver.NextGenDocumentRepository.EP.Highlight();
                FastDriver.NextGenDocumentRepository.EP.FASetCheckbox(true);
                Playback.Wait(3000);

                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);

                Reports.TestStep = "Add the second document to Inerface Queue";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "PO-Commission Instructions PDFDocument", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddInterfaceQueue.FAMouseOver();
                FastDriver.NextGenDocumentRepository.EP.Highlight();
                FastDriver.NextGenDocumentRepository.EP.FASetCheckbox(true);
                Playback.Wait(3000);
                               
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EGtempnameanddesc, "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                              
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT IS/ARE ADDED TO INTERFACE QUEUE AND CANNOT BE REMOVED.", "Error Message Verified");
                               
                Playback.Wait(7000);

                Reports.TestStep = "Verify other documents got deleted from the documents list";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Deleted");



                Reports.TestStep = "Navigate to Document Repository Screen to add Endorsement/Guarantee document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify other documents got deleted from the documents list";


                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Deleted");
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Deleted");

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName11 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString();
                docName11 = docName11.Trim();
                Support.AreEqual("True", docName11, "Endorsement/Guarantee exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen to add Escrow Instruction document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName22 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString();
                docName22 = docName22.Trim();
                Support.AreEqual("True", docName22, "Escrow Instruction exists on the Search Result Table");



                Reports.TestStep = "Filter only Image Documents";

                FastDriver.NextGenDocumentRepository.FilterImageDoc();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select all the documents from the list";

                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Deleting all documents from the list";

                FastDriver.NextGenDocumentRepository.RemoveMulti.FASelectContextMenuItem();
                                
                Playback.Wait(5000);

                Reports.TestStep = "Validate the error message that imaged documents cannot be removed";

                string errormsgfilter = FastDriver.WebDriver.HandleDialogMessage();
                errormsgfilter = errormsgfilter.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsgfilter, "DOCUMENT(S) MISCELLANEOUS PDFDOCUMENT,PO-COMMISSION INSTRUCTIONS PDFDOCUMENT IS/ARE ADDED TO INTERFACE QUEUE AND CANNOT BE REMOVED.", "Error Message Verified");

                Reports.TestStep = "Remove filters from Type Column";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ClearTypeFilter();

                Playback.Wait(3000);

                Reports.TestStep = "Verify none of the documents got deleted";

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("Miscellaneous PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("PO-Commission Instructions PDFDocument").ToString(), "Image Doc- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Exists");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Inst- Exists");


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        




        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
