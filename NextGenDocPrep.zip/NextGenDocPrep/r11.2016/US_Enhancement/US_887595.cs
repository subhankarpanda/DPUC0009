﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace NextGenDocPrep.r11._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_887595 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {


            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        [TestMethod]
        public void TC_902205_902269_904164()
        {
            try
            {
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                Reports.TestDescription = "Verify the Keyword Text box for existing Phrase";

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();

                Reports.TestStep = "Search for a phrase group.";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.SelectPhraseType("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText("GOAL*");

                Reports.TestStep = "Click on Search button";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Right click the Phrase and select Properties from context menu";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.PerformTableAction(1, 3, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.WaitCreation(FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_ContextMenu);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Properties.FASelectContextMenuItem();

                Reports.TestStep = "selects a Phrase from the Phrases list";
                FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Status", "Active", "Status", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "right clicks on the Phrase and select ‘Properties’";
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();

                Reports.TestStep = "Verify the Keyword Textbox";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.Exists();
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.IsEnabled().ToString());
                Reports.TestStep = "Enter a keyword value";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("Keyword123");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();


                Reports.TestStep = "Verify the Saved Phrase Keyword";
                Support.AreEqual("Keyword123", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Saved successfully");

                Reports.TestDescription = "Verify the Keyword Text box for New Phrases";
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");
                Reports.TestStep = "Enter Special characters keyword and validate warning message";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("^%%^&*(((**^^%");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "Verify the warning message when invalid keyword is entered";
                string errormessage0 = "Keyword may only contain 0-9 a-z A-Z characters";
                FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: errormessage0);

                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("ABCD7890,123456DEFG,123ab67890,12XY567");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();

                Reports.TestStep = "Verify the Saved Phrase Keyword";
                Support.AreEqual("ABCD7890,123456DEFG,123ab67890,12XY567", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Saved successfully");

                Reports.TestDescription = "Add Keyword for a Phrase from Template Subtab Phrases";

                Reports.TestStep = "Search for any existing Template";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");   
                
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                Playback.Wait(3000);
                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();
                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("KeywordFromTemplatePhrase");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();
                Support.AreEqual("KeywordFromTemplatePhrase", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Saved successfully");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TC_904254_905096_905340_906609()
        {
            try
            {
                //Template Editor Phrase Search from ADM and Document View Phrase Search from IIS to be automated with below scenarios  

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestDescription = "Verify the Phrase Search with Keyword in ADM";

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");

                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("Phrase,Keyword");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup to add an another phrase";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW2 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW2);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW2 + "--Phrase");
                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("Keyword,Alpha123");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                Reports.TestDescription = "Verify the Phrase search with the Ivalid keywords";
                Reports.TestStep = "Enter Invalid Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("&^%$#@!?");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                            
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Phrase,Keyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestDescription = "Verify the Phrase search with the keywords using wild card '*'search";
                Reports.TestDescription = "Verify the Keyword Phrase search where Phrases has duplicate keyword within same group";

                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();               
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                Reports.TestStep = "Enter Phrase Keyword with wild card *";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Keyword*");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW2).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestDescription = "Verify the Phrase Search with Keyword in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestDescription = "Verify the Phrase search with the Ivalid keywords";
                Reports.TestStep = "Enter Invalid Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("&^%$#@!?");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Phrase,Keyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestDescription = "Verify the Phrase search with the keywords using wild card '*'search";
                Reports.TestDescription = "Verify the Keyword Phrase search where Phrases has duplicate keyword within same group";

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestStep = "Enter Phrase Keyword with wild card *";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Keyword*");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW2).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }



        }

        [TestMethod]
        public void TC_906744_907489()
        {
            try
            {
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestDescription = "Verify the Phrases with duplicate Keyword from different Phrase groups in ADM";

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab.";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("PhraseDesc");

                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("DuplicateKeyword");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "Create another Phrase group";
                FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClickAction();

                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName1 = RandomString(4);
                string randomName_2 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_2);
                var GRPname_2 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                var phrasetype_2 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_2 = "TEST--" + "Endorse--" + GRPname_2;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_2);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW2 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW2);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("PhraseDesc");

                Reports.TestStep = "Enter valid 40 character length Alphanumeric keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("DuplicateKeyword");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                Reports.TestDescription = "Verify the Phrase search with the Description and keyword";
                Reports.TestStep = "Enter Invalid Phrase description and valid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("InvalidDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("DuplicateKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase description and Invalid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("PhraseDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("InvalidKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase description and valid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("PhraseDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("DuplicateKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(randomName_1+"/"+RandomsName_NEW1).ToString());
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(randomName_2+"/"+RandomsName_NEW2).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction("Description", "PhraseDesc", "Description", TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestDescription = "Verify the Phrases with duplicate Keyword from different Phrase groups in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestDescription = "Verify the Phrase search with the Description and keyword";
                Reports.TestStep = "Enter Invalid Phrase description and valid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("InvalidDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("DuplicateKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase description and Invalid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("PhraseDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("InvalidKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Valid Phrase description and valid keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText("PhraseDesc");
                FastDriver.PhraseSelectDlg.Keyword.FASetText("DuplicateKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(randomName_1 + "/" + RandomsName_NEW1).ToString());
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(randomName_2 + "/" + RandomsName_NEW2).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction("Description", "PhraseDesc", "Description", TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }



        }

        [TestMethod]
        public void TC_907590_909897()
        {
            try
            {
                Reports.TestDescription = "Verify the Phrase Keyword when a Phrase is Copied to new Phrase";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();

                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");
                Reports.TestStep = "Enter valid keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("CopyPhraseKeyword");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Status", "Active", "Status", TableAction.GetCell).Element.FARightClick();
                Reports.TestStep = "Rightclick the phrase and select Copy Phrase option";
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseContextMenu.FAFindElement(ByLocator.ClassName, "copyPhrase").FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW2 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW2);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("PhraseDesc");
                Reports.TestStep = "verify the copied phrase";
                Support.AreEqual("CopyPhraseKeyword", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Copied successfully");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Description", "PhraseDesc", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();
                Reports.TestStep = "verify the copied phrase after phrase save";
                Support.AreEqual("CopyPhraseKeyword", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Copied successfully");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("InactivePhraseKeyword");
                Reports.TestStep = "Inactivate the Phrase";
                if (FastDriver.NextGenDocumentPreparation.Status_InActive.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.Status_InActive.FAClickAction(); }

                Reports.TestStep = " Enters Status Change Comments";
                FastDriver.NextGenDocumentPreparation.PhraseEditRvHisTab_commenttxt.FASetText("Phrase is Inactived");

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup to create and add other phrase with under construction checked";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW3 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW3);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TestDesc");
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);

                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("IndiaGate");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                //---------------------------------------------------------------------------------------------------------

                Reports.TestDescription = "Verify the Phrase search with keyword when phrase is Inactive/Underconstruction in ADM";

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                Reports.TestDescription = "Verify the Phrase search with the Description and keyword";

                Reports.TestStep = "Enter Inactive Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PhraseSelectDlg.Keyword.FASetText("InactivePhraseKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Underconstruction Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();

                FastDriver.PhraseSelectDlg.Keyword.FASetText("IndiaGate");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestDescription = "Verify the Phrase search with Description and keyword in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestStep = "Enter Inactive Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PhraseSelectDlg.Keyword.FASetText("InactivePhraseKeyword");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

                Reports.TestStep = "Enter Underconstruction Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();

                FastDriver.PhraseSelectDlg.Keyword.FASetText("IndiaGate");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Validate that there is no Phrase results";
                Support.AreEqual("0", FastDriver.PhraseSelectDlg.ResultsTable.GetRowCount().ToString());

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TC_909948()
        {
            try
            {
                Reports.TestDescription = "Verify whether Keyword is copied to new Phrase when Phrase is copied from Copy/Move Phrases tab";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                
                Reports.TestDescription = "Create new phrase group";
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup Tab";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4).ToUpper(); ;
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "User selects phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();

                Reports.TestStep = "User enters a description.";
                var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                Reports.TestStep = "User saves the new phrase group.";
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                Reports.TestStep = "Enter valid keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("SourceKeyword");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                var phrase1code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                /*Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_2 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                var phrase2code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);*/
                               
                Reports.TestDescription = "Create new phrase group2";
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup Tab";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                Reports.TestStep = "System displays the Phrase Group Maintenance screen";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "User enters a unique 4-character name for the new phrase group.";
                string randomName_1 = RandomString(4).ToUpper(); ;
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "User selects phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                Reports.TestStep = "User saves the new phrase group.";
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                Reports.TestStep = "Click on Copy/Move Phrases tab";
                FastDriver.NextGenDocumentPreparation.CopyMovePhrases.FAClickAction();
                Playback.Wait(3000);
                                                
                Reports.TestDescription = "Copy a Phrase from one group to another group ";
                Reports.TestStep = "Select the region From where Phrase should copied";
                FastDriver.NextGenDocumentPreparation.FirstFormRegion.FASelectItem("QA Sandpointe - Next Gen");
                Reports.TestStep = "Select the phrase group From";
                FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormGroup.FASelectItem(GRPname);

                Reports.TestStep = "select the phrase From Table List which have to copy";
                FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormPhraseCodeSelect.FAClickAction();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase_Done.FAClickAction();
                Playback.Wait(2500);

                Reports.TestStep = "Select the region where Phrase to be copied";
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToRegion.FASelectItem("QA Sandpointe - Next Gen");
                Reports.TestStep = "select the Phrase Group To";
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem(GRPname_1);

                Reports.TestStep = "Enter The Phrase Name which to be copied in name/code of";
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FASetText(phrase1code);
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FASetText(phrase1);
                var ValidationGRP1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FAGetSelectedItem();
                var validationPhrase1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FAGetValue();
                var ValidationPhraseDesc1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FAGetValue();
                Reports.TestStep = "Copy Phrase by click on copy ";
                FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                Playback.Wait(5000);

                Reports.TestStep = "Verification of Copy Successfull.";
                var validationMessgae1 = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();

                Support.AreEqual(validationMessgae1, "No 1:Success");
            
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                Reports.TestStep = " select same phrase type.";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                if (FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction(); Playback.Wait(3000);
                if (FastDriver.NextGenDocumentPreparation.SelectAllPrase.IsDisplayed()) { FastDriver.NextGenDocumentPreparation.SelectAllPrase.FASetCheckbox(true); }
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupPhraseCode.FASetText(ValidationGRP1 + "/" + validationPhrase1);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                Playback.Wait(4000);
                var phraseDesctoValidate1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetText();
                //Support.AreEqual(ValidationPhraseDesc1, phraseDesctoValidate1);
                Support.AreEqual("SourceKeyword", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Copied successfully");
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TC_910003()
        {
            try
            {
                Reports.TestDescription = "Verify that Versioned Phrase is not pulled in Phrase search when Phrase has UnderConstruction checked and keyword is modified";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();

                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Phrase Desc before versioning");
                Reports.TestStep = "Enter valid keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("KeywordVer1");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Reports.TestStep = "Update the Phrase contents with UnderConstruction";
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Phrase Desc after versioning");
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);

                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("KeywordVer2");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                //---------------------------------------------------------------------------------------------------------

                Reports.TestDescription = "Verify the Phrase search with keyword when phrase is Inactive/Underconstruction in ADM";

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                
                Reports.TestStep = "Enter updated Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PhraseSelectDlg.Keyword.FASetText("KeywordVer2");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that System displays the old version of Phrase in the search result.";
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable("Phrase Desc before versioning").ToString());

                Reports.TestDescription = "Verify the Phrase search with Description and keyword in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                
                //Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Title Reports", "Type", TableAction.Click).Element.FARightClick();
                //FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestStep = "Enter updated Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();

                FastDriver.PhraseSelectDlg.Keyword.FASetText("KeywordVer2");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that System displays the old version of Phrase in the search result.";
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable("Phrase Desc before versioning").ToString());
                
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TC_910009()
        {
            try
            {
                //Versioning scenarios with editor to be automated
                Reports.TestDescription = "Verify that Versioned Phrase is pulled in Phrase search when phrase is searched with keyword";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();

                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Phrase Desc before versioning");
                Reports.TestStep = "Enter valid keyword";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("KeywordVer1");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Reports.TestStep = "Update the Phrase contents with UnderConstruction";
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Phrase Desc after versioning");
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);

                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("KeywordVer2");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Reports.TestStep = "remove the phrase UnderConstruction";
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                //---------------------------------------------------------------------------------------------------------

                Reports.TestDescription = "Verify the Phrase search with keyword when phrase is Inactive/Underconstruction in ADM";

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();


                Reports.TestStep = "Enter updated Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PhraseSelectDlg.Keyword.FASetText("KeywordVer2");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that System displays the old version of Phrase in the search result.";
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable("Phrase Desc after versioning").ToString());

                Reports.TestDescription = "Verify the Phrase search with Description and keyword in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(9000);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();

                Reports.TestStep = "Enter updated Phrase keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();

                FastDriver.PhraseSelectDlg.Keyword.FASetText("KeywordVer2");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that System displays the old version of Phrase in the search result.";
                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable("Phrase Desc after versioning").ToString());

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        public string RandomString(int Size)
        {
            //string input = "abcdefghijklmnopqrstuvwxyz0123456789";
            //StringBuilder builder = new StringBuilder();
            //char ch;
            Random rand = new Random();

            string Alphabet = "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] chars = new char[Size];
            for (int i = 0; i < Size; i++)
            {
                chars[i] = Alphabet[rand.Next(Alphabet.Length)];
            }
            return new string(chars);


        }

        public int SearchExistingTemplate(string temptype, string tempdesc)
        {

            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(temptype);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempdesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            Playback.Wait(5000);
            int table_rows = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetRowCount();

            return table_rows;
        }


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}