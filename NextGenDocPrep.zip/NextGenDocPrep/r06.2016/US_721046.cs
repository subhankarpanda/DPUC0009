﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    
    [CodedUITest]
    //User Story_721046 : System does not force the user to enter a comment when deleting the phrase from Editor
    public class US_721046 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create a template with single phrase (or) Verify for a template if it is already exists";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Template (if not already exit in environment)
            // TC762190 TestCase762190   => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
           
            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1","Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }
       
        [TestMethod]
        [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
        public void TestCase_762190()
        {
            try
            {
                //Pre-Condition: FAST Admin side Create a Template with Single Phrase
                LoadTemplateOrCreateNew("TC762190", "TestCase762190", "Escrow Instruction");

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region 1. Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region 2. Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region 3. Search for a template using template search criteria which is created in Pre-Condition
                Reports.TestStep = "Search for a template using template search criteria which is created in Pre-Condition";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TestCase762190");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region 4. Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "TestCase762190").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region 5. Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TestCase762190", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "TestCase762190", "Document exists on the Search Result Table");
                #endregion

                #region 6. Select the document and Navigate to Phrase View/Data Element View
                Reports.TestStep = "Select the document and Navigate to Phrase View/Data Element View";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TestCase762190", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 60);
                #endregion

                #region 7. Click on Phrase View Tab and Verify "Delete" option is disabled when only single phrase is available in Phrase View

                Reports.TestStep = "Click on Phrase View Tab and Verify \"Delete\" option is disabled when only single phrase is available in Phrase View";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 60);
                FastDriver.NextGenDocumentRepository.SelectPhraseandRightClick("Form: Jacket-ALTA EAGLE LP..");
                FastDriver.NextGenDocumentRepository.Delete_PhraseContext.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.DeletePhraseReason.FASendKeys("Testing delete");
                FastDriver.NextGenDocumentRepository.Done_Reasonbutton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Deleting.. please wait...", false, 60);
                FastDriver.NextGenDocumentRepository.SelectPhraseandRightClick("Fax Cover Sheet");
                FastDriver.NextGenDocumentRepository.Delete_PhraseContext.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.DeletePhraseReason.FASendKeys("Testing delete");
                FastDriver.NextGenDocumentRepository.Done_Reasonbutton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Deleting.. please wait...", false, 60);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 30);

                Reports.TestStep = "Verify document should be present in the phrase view screen";
                FastDriver.NextGenDocumentRepository.SelectPhraseandRightClick("Fax Cover Sheet");
                Playback.Wait(2000);                           

                #endregion



            }
           catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
