﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_721954 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Template (if not already exit in environment)

            // TC784858 TestCase784858   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }


        [TestMethod]
        public void TestCase_784858()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed for State/ County/ City in the filter selection dialog -suggested filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC784858", "TestCase784858", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase784858");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                #region 4. Select a Template and right click for View/Edit Template option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase784858", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");
                
                Reports.TestStep = "Click on \"Edit Filter\" Icon";
                
                //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group 
                //EditFilter.FAClick();
               
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AK", "Select", TableAction.Off);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AL", "Select", TableAction.Off);
                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except AK,AL is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExistsAK = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("AK").ToString();

                Support.AreEqual("False", isStrExistsAK, "Unchecked Geographic Filter State is not present");

                string isStrExistsAL = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("AL").ToString();

                Support.AreEqual("False", isStrExistsAL, "Unchecked Geographic Filter State is not present");

                #region Under the Geographic Filter In the state row click on "Add/Remove" button
                // Note: By default All values are selected under geographic filter - do we need to verify this?
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                #region Set "CA" check box and click on "Select" button
                Reports.TestStep = "Set \"CA\" check box and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                #endregion

                #region Verify CA is displayed under Geographic filter
                Reports.TestStep = "Verify CA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("CA", FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Trim(), "Geographic Filter State");
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);

                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ALAMEDA", "Select", TableAction.Off);
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ALPINE", "Select", TableAction.Off);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except ALAMEDA,ALPINE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExistsALAMEDA = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("ALAMEDA").ToString();
                Support.AreEqual("False", isStrExistsALAMEDA, "Unchecked Geographic Filter State is not present");

                string isStrExistsALPINE = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("ALPINE").ToString();
                Support.AreEqual("False", isStrExistsALPINE, "Unchecked Geographic Filter State is not present");

                #endregion


                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);


                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "ORANGE" check box and click on "Select" button
                Reports.TestStep = "Set \"ORANGE\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ORANGE", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify ORANGE is displayed under Geographic filter
                Reports.TestStep = "Verify ORANGE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("ORANGE", FastDriver.NextGenDocumentPreparation.GeographicFilterCounty.FAGetText().Trim(), "Geographic Filter County");
                #endregion

                #region In the City row click on "Add/Remove" button
                Reports.TestStep = "In the City row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CityAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("City Selection", true, 15);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);

                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "ALISO VIEJO", "Select", TableAction.Off);
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "ANAHEIM", "Select", TableAction.Off);
                FastDriver.CountySelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except ALAMEDA,ALPINE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExistsALISO = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("ALISO VIEJO").ToString();
                Support.AreEqual("False", isStrExistsALISO, "Unchecked Geographic Filter State is not present");

                string isStrExistsANAHEIM = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Contains("ANAHEIM").ToString();
                Support.AreEqual("False", isStrExistsANAHEIM, "Unchecked Geographic Filter State is not present");

                #endregion

             #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TestCase_784871()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed for State/ County/ City in the filter selection dialog -suggested filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC784858", "TestCase784858", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase784858");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                #region 4. Select a Template and right click for View/Edit Template option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase784858", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");

                Reports.TestStep = "Click on \"Edit Filter\" Icon";

                //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group 
                //EditFilter.FAClick();

                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AK", "Select", TableAction.Off);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AL", "Select", TableAction.Off);

                List<string> AllStates = FastDriver.NextGenDocumentPreparation.GetSelectedItemsTables();

                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except AK,AL is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExists = null;

                foreach (var item in AllStates)
	            {
                    isStrExists = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetAttribute("title").Contains(item).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Geographic Filter State is present");
	            }   

                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }
        [TestMethod]
        public void TestCase_784849()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed after Show/Hide filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC784849", "TestCase784849", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase784858");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase784858", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");

                Reports.TestStep = "Click on \"Edit Filter\" Icon";

                //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group 
                //EditFilter.FAClick();

                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                
                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                #region Set "CA" check box and click on "Select" button
                Reports.TestStep = "Set \"CA\" check box and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                #endregion

                #region Verify CA is displayed under Geographic filter
                Reports.TestStep = "Verify CA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("CA", FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Trim(), "Geographic Filter State");
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "ORANGE" check box and click on "Select" button
                Reports.TestStep = "Set \"ORANGE\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ORANGE", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify ORANGE is displayed under Geographic filter
                Reports.TestStep = "Verify ORANGE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("ORANGE", FastDriver.NextGenDocumentPreparation.GeographicFilterCounty.FAGetText().Trim(), "Geographic Filter County");
                #endregion

                #region In the City row click on "Add/Remove" button
                Reports.TestStep = "In the City row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CityAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("City Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(null, true);  // City Selection
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "SANTA ANA" check box and click on "Select" button
                Reports.TestStep = "Set \"SANTA ANA\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "SANTA ANA", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify SANTA ANA is displayed under Geographic filter
                Reports.TestStep = "Verify SANTA ANA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("SANTA ANA", FastDriver.NextGenDocumentPreparation.GeographicFilterCity.FAGetText().Trim(), "Geographic Filter City");
                #endregion

                FastDriver.NextGenDocumentPreparation.ServiceTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.PropertyTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.BusinessSegmentSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TransactionTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.SearchTypeSelectAll.FASetCheckbox(false);



                #region Set "Title" and "Escrow" check boxes under service type
                Reports.TestStep = "Set \"Title\" and \"Escrow\" check boxes under service type";
                FastDriver.NextGenDocumentPreparation.Title.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Escrow.FASetCheckbox(true);
                #endregion

                #region Select "Single Family Residence" Property Type
                Reports.TestStep = "Select \"Single Family Residence\" Property Type";
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                #endregion

                #region Select "ALTA Expanded (Eagle Loan) Polcy" Product
                Reports.TestStep = "Select multiple Products";
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency File Scanning");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Policy Typing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Post Closing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Extended Loan Policy");
                #endregion

                var productslist = FastDriver.NextGenDocumentPreparation.Products.FindElements(OpenQA.Selenium.By.TagName("OPTION"));
                List<string> str = new List<string>();
                foreach (var item in productslist)
                {
                    if (item.Selected == true)
	{
        str.Add(item.Text);
	}
                    
                }

                #region Select "Residential" Business Segment
                Reports.TestStep = "Select \"Residential\" Business Segment";
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                #endregion

                #region Select "Accommodation" Transaction Type
                Reports.TestStep = "Select \"Accommodation\" Transaction Type";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Accommodation");
                #endregion

                #region Clcik on "Done" button
                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                #endregion

                #region Under Suggested Filter Group selected filtering Values will be displayed
                Reports.TestStep = "Under Suggested Filter Group selected filtering Values will be displayed";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                var filterContent = FastDriver.NextGenDocumentPreparation.FilterTable.GetAttribute("textContent");
                Support.AreEqual("True", filterContent.Contains("CA").ToString(), "Filter contains CA");
                Support.AreEqual("True", filterContent.Contains("ORANGE").ToString(), "Filter contains ORANGE");
                Support.AreEqual("True", filterContent.Contains("SANTA ANA").ToString(), "Filter contains SANTA ANA");
                Support.AreEqual("True", filterContent.Contains("Title, Escrow").ToString(), "Filter contains Title, Escrow");
                Support.AreEqual("True", filterContent.Contains("Accommodation").ToString(), "Filter contains Accommodation");
                Support.AreEqual("True", filterContent.Contains("Single Family Residence").ToString(), "Filter contains Single Family Residence");
                Support.AreEqual("True", filterContent.Contains("ALTA Expanded (Eagle Loan) Policy").ToString(), "Filter contains ALTA Expanded (Eagle Loan) Policy");
                Support.AreEqual("True", filterContent.Contains("Residential").ToString(), "Filter contains Residential");
                #endregion

                #region Click on "Save" Button
                Reports.TestStep = "Click on \"Save\" Button";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                Reports.TestStep = "Click on Hide Filters Button";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Save);
                // To click on Hide all filters 
                Keyboard.SendKeys("%{H}");

                Reports.TestStep = "Click on Show Filters Button";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Save);
                // To click on Show all filters 
                Keyboard.SendKeys("%{O}");

                Playback.Wait(1000);

                string isStrExists = null;

                foreach (var item in str)
                {
                    isStrExists = FastDriver.NextGenDocumentPreparation.SelectedProducts.FAGetAttribute("title").Replace("<br/>"," ").Contains(item).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Product Type is present");
                }   

              
                Playback.Wait(1000);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TestCase_784847()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed after copying a suggested filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC784849", "TestCase784849", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase784858");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase784858", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");

                Reports.TestStep = "Click on \"Edit Filter\" Icon";

                //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group 
                //EditFilter.FAClick();

                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                #region Set "CA" check box and click on "Select" button
                Reports.TestStep = "Set \"CA\" check box and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                #endregion

                #region Verify CA is displayed under Geographic filter
                Reports.TestStep = "Verify CA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("CA", FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Trim(), "Geographic Filter State");
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "ORANGE" check box and click on "Select" button
                Reports.TestStep = "Set \"ORANGE\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ORANGE", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify ORANGE is displayed under Geographic filter
                Reports.TestStep = "Verify ORANGE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("ORANGE", FastDriver.NextGenDocumentPreparation.GeographicFilterCounty.FAGetText().Trim(), "Geographic Filter County");
                #endregion

                #region In the City row click on "Add/Remove" button
                Reports.TestStep = "In the City row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CityAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("City Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(null, true);  // City Selection
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "SANTA ANA" check box and click on "Select" button
                Reports.TestStep = "Set \"SANTA ANA\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "SANTA ANA", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify SANTA ANA is displayed under Geographic filter
                Reports.TestStep = "Verify SANTA ANA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("SANTA ANA", FastDriver.NextGenDocumentPreparation.GeographicFilterCity.FAGetText().Trim(), "Geographic Filter City");
                #endregion

                FastDriver.NextGenDocumentPreparation.ServiceTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.PropertyTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.BusinessSegmentSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TransactionTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.SearchTypeSelectAll.FASetCheckbox(false);



                #region Set "Title" and "Escrow" check boxes under service type
                Reports.TestStep = "Set \"Title\" and \"Escrow\" check boxes under service type";
                FastDriver.NextGenDocumentPreparation.Title.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Escrow.FASetCheckbox(true);
                #endregion

                #region Select "Single Family Residence" Property Type
                Reports.TestStep = "Select \"Single Family Residence\" Property Type";
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                #endregion

                #region Select "ALTA Expanded (Eagle Loan) Polcy" Product
                Reports.TestStep = "Select multiple Products";
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency File Scanning");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Policy Typing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Post Closing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Extended Loan Policy");
                #endregion

                var productslist = FastDriver.NextGenDocumentPreparation.Products.FindElements(OpenQA.Selenium.By.TagName("OPTION"));
                List<string> str = new List<string>();
                foreach (var item in productslist)
                {
                    if (item.Selected == true)
                    {
                        str.Add(item.Text);
                    }

                }

                #region Select "Residential" Business Segment
                Reports.TestStep = "Select \"Residential\" Business Segment";
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                #endregion

                #region Select "Accommodation" Transaction Type
                Reports.TestStep = "Select \"Accommodation\" Transaction Type";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Accommodation");
                #endregion

                #region Clcik on "Done" button
                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                #endregion

                #region Under Suggested Filter Group selected filtering Values will be displayed
                Reports.TestStep = "Under Suggested Filter Group selected filtering Values will be displayed";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                var filterContent = FastDriver.NextGenDocumentPreparation.FilterTable.GetAttribute("textContent");
                Support.AreEqual("True", filterContent.Contains("CA").ToString(), "Filter contains CA");
                Support.AreEqual("True", filterContent.Contains("ORANGE").ToString(), "Filter contains ORANGE");
                Support.AreEqual("True", filterContent.Contains("SANTA ANA").ToString(), "Filter contains SANTA ANA");
                Support.AreEqual("True", filterContent.Contains("Title, Escrow").ToString(), "Filter contains Title, Escrow");
                Support.AreEqual("True", filterContent.Contains("Accommodation").ToString(), "Filter contains Accommodation");
                Support.AreEqual("True", filterContent.Contains("Single Family Residence").ToString(), "Filter contains Single Family Residence");
                Support.AreEqual("True", filterContent.Contains("ALTA Expanded (Eagle Loan) Policy").ToString(), "Filter contains ALTA Expanded (Eagle Loan) Policy");
                Support.AreEqual("True", filterContent.Contains("Residential").ToString(), "Filter contains Residential");
                #endregion

                #region Click on "Save" Button
                Reports.TestStep = "Click on \"Save\" Button";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                Reports.TestStep = "Click on \"CopyGroupFilter\" Icon";
                FastDriver.NextGenDocumentPreparation.CopyGroupFilter.FAClick();


                Playback.Wait(1000);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TestCase_724148()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed after copying a suggested filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC724148", "TestCase724148", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase724148");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase724148", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");

                Reports.TestStep = "Click on \"Edit Filter\" Icon";

                //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group 
                //EditFilter.FAClick();

                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                #region Set "CA" check box and click on "Select" button
                Reports.TestStep = "Set \"CA\" check box and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                #endregion

                #region Verify CA is displayed under Geographic filter
                Reports.TestStep = "Verify CA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("CA", FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Trim(), "Geographic Filter State");
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "ORANGE" check box and click on "Select" button
                Reports.TestStep = "Set \"ORANGE\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ORANGE", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify ORANGE is displayed under Geographic filter
                Reports.TestStep = "Verify ORANGE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("ORANGE", FastDriver.NextGenDocumentPreparation.GeographicFilterCounty.FAGetText().Trim(), "Geographic Filter County");
                #endregion

                #region In the City row click on "Add/Remove" button
                Reports.TestStep = "In the City row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CityAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("City Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(null, true);  // City Selection
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "SANTA ANA" check box and click on "Select" button
                Reports.TestStep = "Set \"SANTA ANA\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "SANTA ANA", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify SANTA ANA is displayed under Geographic filter
                Reports.TestStep = "Verify SANTA ANA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("SANTA ANA", FastDriver.NextGenDocumentPreparation.GeographicFilterCity.FAGetText().Trim(), "Geographic Filter City");
                #endregion

                FastDriver.NextGenDocumentPreparation.ServiceTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.PropertyTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.BusinessSegmentSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TransactionTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.SearchTypeSelectAll.FASetCheckbox(false);



                #region Set "Title" and "Escrow" check boxes under service type
                Reports.TestStep = "Set \"Title\" and \"Escrow\" check boxes under service type";
                FastDriver.NextGenDocumentPreparation.Title.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Escrow.FASetCheckbox(true);
                #endregion

                #region Select "Single Family Residence" Property Type
                Reports.TestStep = "Select \"Single Family Residence\" Property Type";
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                #endregion

                #region Select "ALTA Expanded (Eagle Loan) Polcy" Product
                Reports.TestStep = "Select multiple Products";
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency File Scanning");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Policy Typing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Post Closing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Extended Loan Policy");
                #endregion

                var productslist = FastDriver.NextGenDocumentPreparation.Products.FindElements(OpenQA.Selenium.By.TagName("OPTION"));
                List<string> str = new List<string>();
                foreach (var item1 in productslist)
                {
                    if (item1.Selected == true)
                    {
                        str.Add(item1.Text);
                    }

                }

                #region Select "Residential" Business Segment
                Reports.TestStep = "Select \"Residential\" Business Segment";
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                #endregion

                #region Select "Accommodation" Transaction Type
                Reports.TestStep = "Select \"Accommodation\" Transaction Type";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Accommodation");
                #endregion

                #region Clcik on "Done" button
                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                #endregion

                #region Under Suggested Filter Group selected filtering Values will be displayed
                Reports.TestStep = "Under Suggested Filter Group selected filtering Values will be displayed";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                var filterContent = FastDriver.NextGenDocumentPreparation.FilterTable.GetAttribute("textContent");
                Support.AreEqual("True", filterContent.Contains("CA").ToString(), "Filter contains CA");
                Support.AreEqual("True", filterContent.Contains("ORANGE").ToString(), "Filter contains ORANGE");
                Support.AreEqual("True", filterContent.Contains("SANTA ANA").ToString(), "Filter contains SANTA ANA");
                Support.AreEqual("True", filterContent.Contains("Title, Escrow").ToString(), "Filter contains Title, Escrow");
                Support.AreEqual("True", filterContent.Contains("Accommodation").ToString(), "Filter contains Accommodation");
                Support.AreEqual("True", filterContent.Contains("Single Family Residence").ToString(), "Filter contains Single Family Residence");
                Support.AreEqual("True", filterContent.Contains("Residential").ToString(), "Filter contains Residential");
                #endregion

                #region Click on "Save" Button
                Reports.TestStep = "Click on \"Save\" Button";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving please wait...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 15);
                #endregion


                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);


                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AK", "Select", TableAction.Off);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AL", "Select", TableAction.Off);

                List<string> AllStates = FastDriver.NextGenDocumentPreparation.GetSelectedItemsTables();

                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except AK,AL is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExists = null;

                foreach (var item in AllStates)
                {
                    isStrExists = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetAttribute("title").Contains(item).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Geographic Filter State is present");
                }

                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Save);
                 
                foreach (var item1 in str)
                {
                    isStrExists = FastDriver.NextGenDocumentPreparation.SelectedProducts.FAGetAttribute("title").Replace("<br/>"," ").Contains(item1).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Product Type is present");
                }   



                Playback.Wait(1000);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TestCase_724064()
        {
            try
            {
                Reports.TestDescription = "To verify a tool tip is displayed after copying a suggested filter";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC724064", "TestCase724064", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Templates tab and search for the template
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TestCase724064");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "TestCase724064", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false, 60);
                string isExistReqFilter = FastDriver.NextGenDocumentPreparation.RequiredFilter.Exists().ToString();
                Support.AreEqual("True", isExistReqFilter, "Required filter button is exists");

                FastDriver.NextGenDocumentPreparation.RequiredFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                Reports.TestStep = "Uncheck first two options and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AK", "Select", TableAction.Off);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AL", "Select", TableAction.Off);

                List<string> AllStates = FastDriver.NextGenDocumentPreparation.GetSelectedItemsTables();

                FastDriver.StateSelectionDlg.Select.FAClick();

                Reports.TestStep = "Verify except AK,AL is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                string isStrExists = null;

                foreach (var item in AllStates)
                {
                    isStrExists = FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetAttribute("title").Contains(item).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Geographic Filter State is present");
                }

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                string selecteallverify = FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FAGetAttribute("Checked");

                if (selecteallverify == "true")
                {
                    FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FAClick();
                }


                Reports.TestStep = "Select multiple Products";
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency File Scanning");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Policy Typing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("Agency Post Closing");
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Extended Loan Policy");

                var productslist = FastDriver.NextGenDocumentPreparation.Products.FindElements(OpenQA.Selenium.By.TagName("OPTION"));
                List<string> str = new List<string>();
                foreach (var item1 in productslist)
                {
                    if (item1.Selected == true)
                    {
                        str.Add(item1.Text);
                    }

                }

                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Save);

                foreach (var item1 in str)
                {
                    isStrExists = FastDriver.NextGenDocumentPreparation.SelectedProducts.FAGetAttribute("title").Replace("<br/>", " ").Contains(item1).ToString();
                    Support.AreEqual("True", isStrExists, "Checked Product Type is present");
                }   


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }


        #region Private methods

        private void CreateDocumentFromTemplate(string templateName, string documentName = "")
        {
            Reports.TestStep = "Create a document: " + documentName;
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateName);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Select the Document , Right-Click and select \"Create\" option from the context";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateName, "Description", TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

            if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5))
            {
                Reports.TestStep = "Select any policy document name from the list and click on \"Done\" button";
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.Dialog_Table.PerformTableAction(2, 1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.Dialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            if (documentName != "")
            {
                Reports.TestStep = "Rename document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(documentName);
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
            }
            else
                documentName = templateName;

            Reports.TestStep = "Verify document creation"; // TODO: search actual Description column
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            var docs = FastDriver.NextGenDocumentRepository.DocumentsTable.GetAttribute("textContent");
            Support.AreEqual("True", docs.Contains(documentName).ToString(), "Document Table contains doc named: " + documentName);

        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    public class ImageBenchException : Exception, System.Runtime.Serialization.ISerializable
    {
        public ImageBenchException() : base() { }

        public ImageBenchException(string message) : base(message) { }

        public ImageBenchException(string format, params object[] args)
            : base(string.Format(format, args)) { }

        public ImageBenchException(string message, Exception innerException)
            : base(message, innerException) { }

        public ImageBenchException(string format, Exception innerException, params object[] args)
            : base(string.Format(format, args), innerException) { }
    }
}
