﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_662945 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

       

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_749888_No_1()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY USER IS ABLE TO ADD SECTION BREAK FROM PHRASE VIEW SCREEN";

                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
              
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                         
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                        
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();
              
                Reports.TestStep = "Adding Section Break Above the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();



                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();
             
               
              
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify the Section Section Break is added above the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                string SBName = FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6,TableAction.GetText).Message;
                SBName = SBName.Trim();
                Support.AreEqual(SBName,"Section Break(Continuous)");                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_749893_No_2()
        {
            try
            {

                Reports.TestDescription = "USER STORY: 662945 - VERIFY 'SECTION BREAK' OPTION SHOULD BE DISABLED IF USER TRIES TO ADD IT ABOVE THE DEFAULT SECTION BREAK";
                
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();
              
                Reports.TestStep = "Verify Section Break Option is disable";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

             
               
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();

                string enable_prop_disable = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                enable_prop_disable = enable_prop_disable.Trim().ToUpper();
                Support.AreEqual(enable_prop_disable, "DISABLEDCSS");

                Reports.TestStep = "Verify Section Break Option is enable";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")).Highlight();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")));

                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].Highlight();

                string enable_prop_enable = FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                enable_prop_enable = enable_prop_enable.Trim().ToUpper();
                Support.AreEqual(enable_prop_enable, "");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773215_No_3()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY USER IS ABLE TO ADD MULTIPLE SECTION BREAK FROM PHRASE VIEW SCREEN AND SAME IS GETTING REFLECTED IN THE DOCUMENT VIEW EDITOR";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

               
                
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);
               
              
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();

                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Adding Section Break Below the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2].Highlight();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")).Highlight();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")));


                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].JSClick();


                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(2);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(2);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("2");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("2");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify the Section Section Break is added above and below the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                string SBNameA = FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.GetText).Message;
                SBNameA = SBNameA.Trim();
                Support.AreEqual(SBNameA, "Section Break(Continuous)");

                string SBNameB = FastDriver.NextGenDocumentRepository.PhraseDataElementTable3.PerformTableAction(1, 6, TableAction.GetText).Message;
                SBNameB = SBNameB.Trim();
                Support.AreEqual(SBNameB, "Section Break(Continuous)");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773217_No_4()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY USER IS ABLE TO EDIT SECTION BREAK FROM PHRASE VIEW SCREEN AND SAME IS GETTING REFLECTED IN THE DELIVERY";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();



                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();

                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                string hrederphrase1 = FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                string footerphrase1 = FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the Section Section Break and saved data";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);
                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].JSClick();

                Playback.Wait(3000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                Support.AreEqual(hrederphrase1,FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual(footerphrase1, FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual("1", FastDriver.SectionBreakDlg.TopMargin.FAGetValue().ToString());
                Support.AreEqual("1", FastDriver.SectionBreakDlg.BottomMargin.FAGetValue().ToString());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.Continious.IsSelected().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.PageContinious.IsSelected().ToString().ToUpper());


                Reports.TestStep = "Editing the data in section break popup";

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(2);
                string hrederphrase2 = FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(2);
                string footerphrase2 = FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.TopMargin.FASetText("2");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("2");
                FastDriver.SectionBreakDlg.NextPage.FAClick();
                FastDriver.SectionBreakDlg.PageRestart.FAClick();
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the Section Section Break and editeddata";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Next Page)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);
                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].JSClick();

                Playback.Wait(3000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                Support.AreEqual(hrederphrase2, FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual(footerphrase2, FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual("2", FastDriver.SectionBreakDlg.TopMargin.FAGetValue().ToString());
                Support.AreEqual("2", FastDriver.SectionBreakDlg.BottomMargin.FAGetValue().ToString());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.NextPage.IsSelected().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.PageRestart.IsSelected().ToString().ToUpper());
                FastDriver.SectionBreakDlg.Cancel.FAClick();
                Playback.Wait(4000);              

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773221_No_5()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY SYSTEM RETAINS THE SAVED DATA IN SECTION BREAK IF USER REFRESH THE PHRASE VIEW SCREEN";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

               FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);

               FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

               FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
               FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);
               FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();

                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                string hrederphrase1 = FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                string footerphrase1 = FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString();
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the Section Section Break and saved the data after refresh";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.RefreshDocument.FAClick();
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(true,true,10,true);
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);
                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].JSClick();
                
                Playback.Wait(3000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                Support.AreEqual(hrederphrase1, FastDriver.SectionBreakDlg.HeaderPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual(footerphrase1, FastDriver.SectionBreakDlg.FooterPhrase.FAGetSelectedItem().ToString());
                Support.AreEqual("1", FastDriver.SectionBreakDlg.TopMargin.FAGetValue().ToString());
                Support.AreEqual("1", FastDriver.SectionBreakDlg.BottomMargin.FAGetValue().ToString());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.Continious.IsSelected().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.SectionBreakDlg.PageContinious.IsSelected().ToString().ToUpper());
                               
                FastDriver.SectionBreakDlg.Cancel.FAClick();
                Playback.Wait(4000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773223_No_6()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY USER IS ABLE TO DELETE SECTION BREAK FROM OPTION LIST AND BY CLICKING ON DELETE BUTTON IN PHRASE VIEW SCREEN";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();



                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();
             

                Playback.Wait(5000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Adding Section Break Below the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")).Highlight();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")));

                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].JSClick();

                Playback.Wait(5000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(2);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(2);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("2");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("2");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Deleting the Section Break from Context Menu and by Delete button";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();


                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));
                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).JSClick();
                
                Playback.Wait(2000);
                FastDriver.DeleteDlg.WaitForScreenToLoad();
                FastDriver.DeleteDlg.DeleteReason.FASetText("Deleting first section break");
                FastDriver.DeleteDlg.Done.FAClick();
                Playback.Wait(7000);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
               
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 4, TableAction.On);

                FastDriver.NextGenDocumentRepository.DeletePhrases.FAClick();
             
                Playback.Wait(2000);
                FastDriver.DeleteDlg.WaitForScreenToLoad();
                FastDriver.DeleteDlg.DeleteReason.FASetText("Deleting second section break");
                FastDriver.DeleteDlg.Done.FAClick();
                Playback.Wait(7000);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                Playback.Wait(7000);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Verify section break got deleted from Phrase View Screen";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();


                string SBNameA = FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.GetText).Message;
                SBNameA = SBNameA.Trim();
                Support.AreNotEqual(SBNameA, "Section Break(Continuous)");

                string SBNameB = FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 6, TableAction.GetText).Message;
                SBNameB = SBNameB.Trim();
                Support.AreNotEqual(SBNameB, "Section Break(Continuous)");
                              
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773224_No_7()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY THAT USER IS NOT ALLOWED TO ADD OR EDIT SECTION BREAK FROM ALL ELEMENTS TAB FOR FINALIZED DOCUMENT";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();
               
                Playback.Wait(5000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Verify that Edit Section Break and Delete Options are Enable";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string enable_prop_esb = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                enable_prop_esb = enable_prop_esb.Trim().ToUpper();
                Support.AreEqual(enable_prop_esb, "");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string enable_prop_delete = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                enable_prop_delete = enable_prop_delete.Trim().ToUpper();
                Support.AreEqual(enable_prop_delete, "");



                Reports.TestStep = "Changing the document status to finalize";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Verify that Section Break, Edit Section Break and Delete Options are Disable";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();



                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string disable_prop_esb = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                disable_prop_esb = disable_prop_esb.Trim().ToUpper();
                Support.AreEqual(disable_prop_esb, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string disable_prop_delete = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                disable_prop_delete = disable_prop_delete.Trim().ToUpper();
                Support.AreEqual(disable_prop_delete, "DISABLEDCSS");


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();

                string disable_prop_sb = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                disable_prop_sb = disable_prop_sb.Trim().ToUpper();
                Support.AreEqual(disable_prop_sb, "DISABLEDCSS");


                Reports.TestStep = "Changing the document status to unfinalize";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();                            

                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("UnFinalized");
                Playback.Wait(2000);

                FastDriver.UnFinalizeDlg.WaitForScreenToLoad();
                FastDriver.UnFinalizeDlg.UnFinalizeReason.FASetText("Unfinalize");
                FastDriver.UnFinalizeDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving please wait...", false, 20);


                Reports.TestStep = "Verify that Section Break, Edit Section Break and Delete Options are Enable";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string enable_prop_esb1 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                enable_prop_esb1 = enable_prop_esb1.Trim().ToUpper();
                Support.AreEqual(enable_prop_esb1, "");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string enable_prop_delete1 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                enable_prop_delete1 = enable_prop_delete1.Trim().ToUpper();
                Support.AreEqual(enable_prop_delete1, "");


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();

                string enable_prop_sb = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                enable_prop_sb = enable_prop_sb.Trim().ToUpper();
                Support.AreEqual(enable_prop_sb, "");

                
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r06_2016_US_662945_TC_773225_No_8()
        {
            try
            {

                Reports.TestDescription = "USER STORY:662945- VERIFY THAT USER IS NOT ALLOWED TO ADD OR EDIT SECTION BREAK FROM EMV TAB";
                LoadTemplateOrCreateNew("US662945-TEMP1", "US-662945-TEMP1", "Endorsement/Guarantee");
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("US-662945-TEMP1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "US-662945-TEMP1").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "US-662945-TEMP1", "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Section Break Above the selected Phrase";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].JSClick();

                Playback.Wait(5000);
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();

                FastDriver.SectionBreakDlg.HeaderPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.FooterPhrase.FASelectItemByIndex(1);
                FastDriver.SectionBreakDlg.TopMargin.FASetText("1");
                FastDriver.SectionBreakDlg.BottomMargin.FASetText("1");
                FastDriver.SectionBreakDlg.Done.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Verify that Section Break, Edit Section Break and Delete Options are Disable in EMV";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FAClick();
                Playback.Wait(5000);

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string disable_prop_esb = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                disable_prop_esb = disable_prop_esb.Trim().ToUpper();
                Support.AreEqual(disable_prop_esb, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string disable_prop_delete = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                disable_prop_delete = disable_prop_delete.Trim().ToUpper();
                Support.AreEqual(disable_prop_delete, "DISABLEDCSS");


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                string disable_prop_sb = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                disable_prop_sb = disable_prop_sb.Trim().ToUpper();
                Support.AreEqual(disable_prop_sb, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                Reports.TestStep = "Changing the document status to finalize";

             
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FAClick();
                Playback.Wait(5000);
                               
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
              
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);


                Reports.TestStep = "Verify that Section Break, Edit Section Break and Delete Options are Disable in EMV";

             
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string disable_prop_esb1 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                disable_prop_esb1 = disable_prop_esb1.Trim().ToUpper();
                Support.AreEqual(disable_prop_esb1, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string disable_prop_delete1 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                disable_prop_delete1 = disable_prop_delete1.Trim().ToUpper();
                Support.AreEqual(disable_prop_delete1, "DISABLEDCSS");


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                string disable_prop_sb1 = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                disable_prop_sb1 = disable_prop_sb1.Trim().ToUpper();
                Support.AreEqual(disable_prop_sb1, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Changing the document status to unfinalize";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "US-662945-TEMP1", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FAClick();
                Playback.Wait(5000);

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("UnFinalized");
                Playback.Wait(2000);

                FastDriver.UnFinalizeDlg.WaitForScreenToLoad();
                FastDriver.UnFinalizeDlg.UnFinalizeReason.FASetText("UnFinalized");
                FastDriver.UnFinalizeDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving please wait...", false, 20);


                Reports.TestStep = "Verify that Section Break, Edit Section Break and Delete Options are Disable in EMV";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click, "Section Break(Continuous)").Element.FARightClick();

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1]);

                string disable_prop_esb2 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[1].FAGetAttribute("class").ToString();
                disable_prop_esb2 = disable_prop_esb2.Trim().ToUpper();
                Support.AreEqual(disable_prop_esb2, "DISABLEDCSS");

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")));


                string disable_prop_delete2 = FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAGetAttribute("class").ToString();
                disable_prop_delete2 = disable_prop_delete2.Trim().ToUpper();
                Support.AreEqual(disable_prop_delete2, "DISABLEDCSS");


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2]);


                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0]);

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3]);

                string disable_prop_sb2 = FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[3].FAGetAttribute("class").ToString();
                disable_prop_sb2 = disable_prop_sb2.Trim().ToUpper();
                Support.AreEqual(disable_prop_sb2, "DISABLEDCSS");
                
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


       





        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
