﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    [CodedUITest]
    public class UserStory_606492 : MasterTestClass
    {
        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion



        [TestMethod]

        public void NEXT_GENT_01_VERIFY_SEARCH_ICON_IS_DISPLAYED_IN_THE_EDITOR_TOOLBAR_AND_TRIGGERS_FIND_AND_REPLACE()
        {
            try
            {


                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Title Reports").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Phrases View
                Reports.TestStep = "Perform Doble Click in Phrases View";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatePhrases.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click the Find/Relace in DE button
                Reports.TestStep = " Click the Find/Relace in DE button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                //
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //                               
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion

            }





            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }



        [TestMethod]

        public void NEXT_GENT_02_VERIFY_SEARCH_FINDS_ALL_THE_AVAILABLE_DE_VALUES_DOCUMENT_EDITOR()
        {
            try
            {

                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion


                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(6, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Right Click View/Edit Document Created
                Reports.TestStep = "Perform Right Click View/Edit Document Created ";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Navegation Left Menu Phrases
                Reports.TestStep = "Navegate Document Edit";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                FALibSL.GetControl("DocumentEditor", "FieldSearch").SendKeys("JL3");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.Tab);
                FALibSL.GetControl("DocumentEditor", "ButtonNext").SendKeys("{ENTER}");
                Playback.Wait(2000);
                #endregion

                #region Click in the  Find and Replace Button
                Reports.TestStep = "Click in the  Find and Replace Button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                Playback.Wait(5000);
                #endregion

                #region Calculate Clickable Point Field Find and Replace
                Reports.TestStep = " Calculate Clickable Point";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataPoint = new System.Drawing.Point(350, 120);
                Mouse.Move(InsertDataPoint);                
                Playback.Wait(3000);
                Mouse.Click(InsertDataPoint);
                Playback.Wait(4000);
                Keyboard.SendKeys("Buyer");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys("CA");
                Playback.Wait(4000);
                #endregion

                #region Click on Control Navegation into DE
                Reports.TestStep = "Click on Control Navegation into DE";
                FALibSL.GetControl("DocumentEditor", "MoveDataDown").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "MoveDataUp").SendKeys("{ENTER}");
                Playback.Wait(5000);
                #endregion

                #region Click Dropdown Find and Replace DE
                Reports.TestStep = " Click Dropdown Find and Replace DE  ";
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindandReplaceinDEButton").Click();
                Playback.Wait(5000);
                #endregion

                #region Calculate Clickable Point field Find and Replace
                Reports.TestStep = "Calculate Clickable Point field Find and Replace";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataFind = new System.Drawing.Point(400, 95);
                var InsertDataReplace = new System.Drawing.Point(700, 95);
                Mouse.Click(InsertDataFind);
                Playback.Wait(4000);
                Mouse.Click(InsertDataFind);
                Playback.Wait(5000);
                Keyboard.SendKeys("1784");
                Mouse.Click(InsertDataReplace);
                Playback.Wait(5000);
                Keyboard.SendKeys("Santa Ana");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindPrevious").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion






            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void NEXT_GENT_03_VERIFY_FIND_AND_REPLACE_FOR_INDIVIDUAL_DE_IN_THE_DOCUMENT_EDITOR()
        {
            try
            {

                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion


                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(6, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Right Click View/Edit Document Created
                Reports.TestStep = "Perform Right Click View/Edit Document Created ";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Navegation Left Menu Phrases
                Reports.TestStep = "Navegate Document Edit";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                FALibSL.GetControl("DocumentEditor", "FieldSearch").SendKeys("JL3");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.Tab);
                FALibSL.GetControl("DocumentEditor", "ButtonNext").SendKeys("{ENTER}");
                Playback.Wait(2000);
                #endregion

                #region Click in the  Find and Replace Button
                Reports.TestStep = "Click in the  Find and Replace Button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                Playback.Wait(5000);
                #endregion

                #region Calculate Clickable Point Field Find and Replace
                Reports.TestStep = " Calculate Clickable Point";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataPoint = new System.Drawing.Point(350, 120);
                Mouse.Move(InsertDataPoint);
                Playback.Wait(3000);
                Mouse.Click(InsertDataPoint);
                Playback.Wait(4000);
                Keyboard.SendKeys("Buyer");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys("CA");
                Playback.Wait(4000);
                #endregion

                #region Click on Control Navegation into DE
                Reports.TestStep = "Click on Control Navegation into DE";
                FALibSL.GetControl("DocumentEditor", "MoveDataDown").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ReplaceButton").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion

                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region Select Preview delivery  Document
                Reports.TestStep = "Select Preview delivery  Document ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("PREVIEW");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void NEXT_GENT_04_VERIFY_FIND_AND_REPLACE_ALL_WITHIN_THE_DOCUMENT_EDITOR()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion


                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Right Click View/Edit Document Created
                Reports.TestStep = "Perform Right Click View/Edit Document Created ";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navegation Left Menu Phrases
                Reports.TestStep = "Navegate Document Edit";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                FALibSL.GetControl("DocumentEditor", "FieldSearch").SendKeys("JL5");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.Tab);
                FALibSL.GetControl("DocumentEditor", "ButtonNext").SendKeys("{ENTER}");
                Playback.Wait(2000);
                #endregion

                #region Click Dropdown Find and Replace Tex
                Reports.TestStep = " Click Dropdown Find and Replace Tex  ";
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                Playback.Wait(5000);
                #endregion

                #region Calculate Clickable Point Field Find and Replace
                Reports.TestStep = " Calculate Clickable Point";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataPoint = new System.Drawing.Point(350, 120);
                Mouse.Move(InsertDataPoint);
                Playback.Wait(3000);
                Mouse.Click(InsertDataPoint);
                Playback.Wait(4000);                
                Keyboard.SendKeys("property");
                Keyboard.SendKeys(FAKeys.Tab);                
                Keyboard.SendKeys("CA");
                Playback.Wait(4000);
                #endregion

                #region Click on Control Navegation into DE
                Reports.TestStep = "Click on Control Navegation into DE";
                FALibSL.GetControl("DocumentEditor", "MoveDataDown").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "MoveDataUp").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ReplaceButton");
                #endregion

                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void NEXT_GENT_05_VERIFY_SEARCH_FINDS_ALL_THE_AVAILABLE_DE_VALUES_IN_THE_DOCUMENT_PHRASE_EDITOR()
        {
            try
            {


                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "EscrowInstruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Phrases View
                Reports.TestStep = "Perform Doble Click in Phrases View";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatePhrases.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click the Find/Relace in DE button
                Reports.TestStep = " Click the Find/Relace in DE button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                //
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //                               
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                #endregion

                #region Calculate Clickable Point Field Find and Replace Tex
                Reports.TestStep = "Calculate Clickable Point Field Find and Replace Tex";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataPoint = new System.Drawing.Point(110, 120);
                Mouse.Move(InsertDataPoint);
                Playback.Wait(3000);
                Mouse.Click(InsertDataPoint);
                Playback.Wait(4000);
                Keyboard.SendKeys("property");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys("CA");
                Playback.Wait(4000);
                #endregion

                #region Click on Control Navegation into DE
                Reports.TestStep = "Click on Control Navegation into DE";
                FALibSL.GetControl("DocumentEditor", "MoveDataDown").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "MoveDataUp").SendKeys("{ENTER}");
                Playback.Wait(5000);
                #endregion

                #region Click Dropdown Find and Replace DE
                Reports.TestStep = " Click Dropdown Find and Replace DE  ";
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindandReplaceinDEButton").Click();
                Playback.Wait(5000);
                #endregion

                #region Calculate Clickable Point field Find and Replace
                Reports.TestStep = "Calculate Clickable Point field Find and Replace";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataFind = new System.Drawing.Point(400, 95);
                var InsertDataReplace = new System.Drawing.Point(700, 95);
                Mouse.Click(InsertDataFind);
                Playback.Wait(4000);
                Mouse.Click(InsertDataFind);
                Playback.Wait(5000);
                Keyboard.SendKeys("CA");
                Mouse.Click(InsertDataReplace);
                Playback.Wait(5000);
                Keyboard.SendKeys("Santa Ana");
                Playback.Wait(5000);
                #endregion

                #region Click Button Next Data Element
                Reports.TestStep = "Click Button Next Data Element ";
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindPrevious").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindPrevious").SendKeys("{ENTER}");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion


                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void NEXT_GENT_06_VERIFY_FIND_AND_REPLACE_FOR_INDIVIDUAL_DE_IN_THE_DOCUMENT_PHRASE_EDITOR()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Endorsement/Guarantee").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Phrases View
                Reports.TestStep = "Perform Doble Click in Phrases View";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatePhrases.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click the Find/Relace in DE button
                Reports.TestStep = " Click the Find/Relace in DE button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                //
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //                               
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindandReplaceinDEButton").Click();
                #endregion

                #region Calculate Clickable Point field Find and Replace
                Reports.TestStep = "Calculate Clickable Point field Find and Replace";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataFind = new System.Drawing.Point(100, 95);
                var InsertDataReplace = new System.Drawing.Point(400, 95);
                Mouse.Click(InsertDataFind);
                Playback.Wait(4000);
                Mouse.Click(InsertDataFind);
                Playback.Wait(5000);
                Keyboard.SendKeys("CA");
                Mouse.Click(InsertDataReplace);
                Playback.Wait(5000);
                Keyboard.SendKeys("Santa Ana");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindNextDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ReplaceIndivDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion

                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region Select Preview delivery  Document
                Reports.TestStep = "Select Preview delivery  Document ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("PREVIEW");
                #endregion




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void NEXT_GENT_07_VERIFY_FIND_AND_REPLACE_ALL_WITHIN_THE_DOCUMENT_PHRASE_EDITOR()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Phrases View
                Reports.TestStep = "Perform Doble Click in Phrases View";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatePhrases.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click the Find/Relace in DE button
                Reports.TestStep = " Click the Find/Relace in DE button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                //
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //                               
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindandReplaceinDEButton").Click();
                #endregion

                #region Calculate Clickable Point field Find and Replace
                Reports.TestStep = "Calculate Clickable Point field Find and Replace";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataFind = new System.Drawing.Point(100, 95);
                var InsertDataReplace = new System.Drawing.Point(400, 95);
                Mouse.Click(InsertDataFind);
                Playback.Wait(4000);
                Mouse.Click(InsertDataFind);
                Playback.Wait(5000);
                Keyboard.SendKeys("CA");
                Mouse.Click(InsertDataReplace);
                Playback.Wait(5000);
                Keyboard.SendKeys("Santa Ana");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindNextDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ReplaceAllDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion

                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region Select Preview delivery  Document
                Reports.TestStep = "Select Preview delivery  Document ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("PREVIEW");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void NEXT_GENT_08_VERIFY_FIND_AND_REPLACE_DE_FUNCTIONALITY_WORKS_IN_DOC_PHRASE_EDITOR()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                Playback.Wait(3000);
                #endregion


                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(6, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Right Click View/Edit Document Created
                Reports.TestStep = "Perform Right Click View/Edit Document Created ";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navegation Left Menu Phrases
                Reports.TestStep = "Navegate Document Edit";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                FALibSL.GetControl("DocumentEditor", "FieldSearch").SendKeys("JL3");
                Keyboard.SendKeys(FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.Tab);
                FALibSL.GetControl("DocumentEditor", "ButtonNext").SendKeys("{ENTER}");
                Playback.Wait(2000);
                #endregion


                #region Click in the  Find and Replace Button
                Reports.TestStep = "Click in the  Find and Replace Button";
                FALibSL.SetParent("DocumentEditor", "DocDeploy");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ButtonFandRText").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindReplaceButton").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindandReplaceinDEButton").Click();
                #endregion

                #region Calculate Clickable Point field Find and Replace
                Reports.TestStep = "Calculate Clickable Point field Find and Replace";
                FastDriver.WebDriver.Manage().Window.Position = new System.Drawing.Point(0, 0);
                var InsertDataFind = new System.Drawing.Point(400, 95);
                var InsertDataReplace = new System.Drawing.Point(700, 95);
                Mouse.Click(InsertDataFind);
                Playback.Wait(4000);
                Mouse.Click(InsertDataFind);
                Playback.Wait(5000);
                Keyboard.SendKeys("Buyer");
                Mouse.Click(InsertDataReplace);
                Playback.Wait(5000);
                Keyboard.SendKeys("Santa Ana");
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "FindNextDE").Highlight();
                FALibSL.GetControl("DocumentEditor", "FindNextDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "ReplaceAllDE").Click();
                Playback.Wait(5000);
                FALibSL.GetControl("DocumentEditor", "SaveButton").Click();
                #endregion

                #region Click Button Close
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(Keys.Enter);

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region Select any Phrases screen
                Reports.TestStep = "Select any Phrases screen ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatePhrases.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion







            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }








        //[TestMethod]
        //public void SAN_NEXTGEN_Validate_FOR_DEBUGGING_DOCUMENT_EDITOR_ONLY()
        //{
        //    try
        //    {

        //        Reports.TestDescription = "Verify Ability to Add Phrase , Misc Pharse and Template in the document editor";

        //        Reports.TestStep = "In the left pane of the Editor Right-Click on InsertPhrase Phrase marker Select Top/Bottom ";
        //        FALibSL.SetParent("DocumentEditor", "Phrases");
        //        FALibSL.GetControl("DocumentEditor", "DocumentArea").Click();
        //        FALibSL.GetControl("DocumentEditor", "Insert").RightClick();
        //        FALibSL.GetControl("DocumentEditor", "Bottom").Click();
        //        FALibSL.GetControl("DocumentEditor", "InsertBottomPhraseSearch").Click();

        //        //FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection");



        //    }
        //    catch (Exception ex)
        //    {
        //        //FailTest(ex.Message);
        //    }

        //}



        //#region Private methods

        //private void CreateDocumentFromTemplate(string templateName, string documentName = "")
        //{
        //    Reports.TestStep = "Create a document: " + documentName;
        //    FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
        //    FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
        //    FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
        //    FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateName);
        //    FastDriver.NextGenDocumentRepository.Search.FAClick();
        //    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

        //    Reports.TestStep = "Select the Document , Right-Click and select \"Create\" option from the context";
        //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        //    FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
        //    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateName, "Description", TableAction.GetCell).Element.FARightClick();
        //    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

        //    if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5))
        //    {
        //        Reports.TestStep = "Select any policy document name from the list and click on \"Done\" button";
        //        FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5);
        //        FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(1, 1, TableAction.Click);
        //        //FastDriver.NextGenDocumentRepository.Dialog_Table.PerformTableAction(2, 1, TableAction.Click);
        //        //FastDriver.NextGenDocumentRepository.Dialog_Done.FAClick();
        //        FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
        //        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
        //    }

        //    if (documentName != "")
        //    {
        //        Reports.TestStep = "Rename document";
        //        FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
        //        FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.GetCell).Element.FARightClick();
        //        FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

        //        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
        //        FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
        //        FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(documentName);
        //        FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
        //    }
        //    else
        //        documentName = templateName;

        //    Reports.TestStep = "Verify document creation"; // TODO: search actual Description column
        //    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
        //    var docs = FastDriver.NextGenDocumentRepository.DocumentsTable.GetAttribute("textContent");
        //    Support.AreEqual("True", docs.Contains(documentName).ToString(), "Document Table contains doc named: " + documentName);

        //}

        //private void SavePDFFile(string PDFFilePath)
        //{
        //    try
        //    {
        //        //TODO: Need to convert this to AutoIt
        //        Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
        //        BrowserWindow AdobeReaderwin = new BrowserWindow();
        //        UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

        //        for (int i = 0; i < Browsercnt.Count; i++)
        //        {
        //            if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
        //            {
        //                AdobeReaderwin.Maximized = true;
        //                break;
        //            }
        //        }

        //        Playback.Wait(5000);

        //        Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
        //        Playback.Wait(2000);
        //        FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

        //        Playback.Wait(2000);
        //        Keyboard.SendKeys("{N}", ModifierKeys.Alt);
        //        Keyboard.SendKeys(PDFFilePath);
        //        Playback.Wait(2000);

        //        Keyboard.SendKeys("{S}", ModifierKeys.Alt);
        //        Playback.Wait(5000);
        //        FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

        //        Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
        //        Playback.Wait(7000);
        //        Support.CloseAllProcessStartingWith("AcroRd32");
        //        Support.CloseAllProcessStartingWith("Acrobat");

        //    }
        //    catch (Exception)
        //    {
        //        //Sometimes the preview window doesn't have name
        //        Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
        //        Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
        //        Playback.Wait(2000);
        //        FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
        //        FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

        //        Keyboard.SendKeys("{N}", ModifierKeys.Alt);
        //        Keyboard.SendKeys(PDFFilePath);
        //        Playback.Wait(5000);

        //        Keyboard.SendKeys("{S}", ModifierKeys.Alt);
        //        Playback.Wait(10000);
        //        FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

        //        Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
        //        Playback.Wait(7000);
        //        Support.CloseAllProcessStartingWith("AcroRd32");
        //        Support.CloseAllProcessStartingWith("Acrobat");

        //    }
        //}

        //#endregion



        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();

        }

    }
}
