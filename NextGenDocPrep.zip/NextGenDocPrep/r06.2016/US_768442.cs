﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_768442 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description","Escrow Instruction QA MJJP Test 1","Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        [TestMethod]
        public void TC_772143()
        {
            try
            {

                Reports.TestDescription = "TO VERIFY THE INFORMATION RELATED TO THE DOCUMENT IN THE DOCUMENT DETAILS TAB FOR THE DOCUMENT IS EDITED - SAME USER";
                LoadTemplateOrCreateNew(Support.RandomString("AAAAAANNNN").ToString(), "TC-772143_772155-TEMP", "Endorsement/Guarantee");
                               
                
                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                                
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC-772143_772155-TEMP");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                         
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "TC-772143_772155-TEMP").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                        
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "TC-772143_772155-TEMP", "Document exists on the Search Result Table");

                

                Reports.TestStep = "Editing the Document Name";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText("TC-772143_772155-TEMP-EDIT");

                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                
                Reports.TestStep = "Verify the Data in Details Tab";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP-EDIT", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();

                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(5000);

                string CUName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName = CUName.Trim();
                Support.AreEqual(CUName, "FAST QA07");

                string SCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName = SCName.Trim();
                Support.AreEqual(SCName, "FAST QA07");

                Reports.TestStep = "Navigating to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP-EDIT", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCUName=FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName = DetailsCUName.Trim();
                Support.AreEqual(DetailsCUName, "FAST QA07");

                string DetailsSCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName = DetailsSCName.Trim();
                Support.AreEqual(DetailsSCName, "FAST QA07");
                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void TC_772155()
        {
            try
            {

                LoadTemplateOrCreateNew(Support.RandomString("AAAAAANNNN").ToString(), "TC-772143_772155-TEMP", "Endorsement/Guarantee");

                Reports.TestDescription = "TO VERIFY THE INFORMATION RELATED TO THE DOCUMENT IN THE DOCUMENT DETAILS TAB FOR THE DOCUMENT IS EDITED - DIFFERENT USER";

                Reports.TestStep = "Login with Automation User";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to File HomePage to get file number";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNumber= FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC-772143_772155-TEMP");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "TC-772143_772155-TEMP").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "TC-772143_772155-TEMP", "Document exists on the Search Result Table");
                               
                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);
                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCUName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName = DetailsCUName.Trim();
                Support.AreEqual(DetailsCUName, "FAST QA07");

                string DetailsSCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName = DetailsSCName.Trim();
                Support.AreEqual(DetailsSCName, "FAST QA07");


                Reports.TestStep = "Login with Super User";

                                
                 #region Login
                 var credentials = new Credentials() { UserName = "faqa-sa-su", Password = "Superuser3" };
                 var credentials1 = new Credentials() { UserName = "feva-sa-su", Password = "superuser" };

                 var url = AutoConfig.FASTHomeURL;
                 string modifiedurl= url.ToString().ToUpper();
                if(modifiedurl.Contains("FINT"))
                     {

                         FASTLogin.Login(url, credentials, true);
                     } 
                if(modifiedurl.Contains("FEVA"))
                     {

                         FASTLogin.Login(url, credentials1, true);
                     } 

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                Reports.StatusUpdate("Current region = " + currentInfo["Region"], true);

                 #endregion



               Reports.TestStep = "Searching for the Same file";


                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Editing the document name";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText("TC-772143_772155-TEMP-EDIT");

                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                

                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP-EDIT", "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CUName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName = CUName.Trim();
                Support.AreEqual(CUName, "FAST QA07");

                string SCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName = SCName.Trim();
                Support.AreEqual(SCName, "Super User");

                Reports.TestStep = "Navigating to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC-772143_772155-TEMP-EDIT", "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCUName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName1 = DetailsCUName1.Trim();
                Support.AreEqual(DetailsCUName1, "FAST QA07");

                string DetailsSCName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName1 = DetailsSCName1.Trim();
                Support.AreEqual(DetailsSCName1, "Super User");

            
        }






            


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }        


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

   
}
