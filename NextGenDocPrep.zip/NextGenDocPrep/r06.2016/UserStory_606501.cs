﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r06._2016
{
    [CodedUITest]
    public class UserStory_606501 : FASTHelpers
    {


        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        [TestMethod]

        public void DocGen_01_Saving_the_Filter_Status_Option()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                string filenumber = "MRKSCOPE10";
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys(filenumber);
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                #endregion

                #region Copy Documents Diferents status
                Reports.TestStep = "Copy Documents Diferents status ";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FARightClick();
                FastDriver.NextGenDocumentRepository.CopyallFile.FASelectContextMenuItem();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.CopyDocuments_Cancel.Highlight();
                FastDriver.NextGenDocumentRepository.CopyDocuments_Cancel.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                  
                #endregion

                #region Click on Status Filter Options
                Reports.TestStep = "Click on Status Filter Option";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();              
                FastDriver.NextGenDocumentRepository.StFilterCreated.FAClick();
                FastDriver.NextGenDocumentRepository.SfilterOk.FAClick();        
                #endregion

                #region Navigate other screen / Remain option filter in the  same option before.
                Reports.TestStep = "Navigate other screen / remain option filter in the  same option before.";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.Open();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();
                #endregion

                #region Select Another Option Filter
                Reports.TestStep = "Select Another Option Filter";
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();
                FastDriver.NextGenDocumentRepository.EditFilter.FAClick();
                FastDriver.NextGenDocumentRepository.SfilterOk.FAClick();
                FastDriver.NextGenDocumentRepository.StatusFilter.FAClick();
                #endregion

            }

           

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        

        [TestMethod]

        public void DocGen_02_Saving_the_Filter_Type_Option()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create different types of Documents in File Documents Landing Page
                FastDriver.NextGenDocumentRepository.CreateAllTypesofDocs();                
                #endregion

                #region Verify Saving filter options for type filter
                Reports.TestStep = "Verify Saving filter options for type filter";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TypeFilter.FAClick();
                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.TypeFilter_FastDocs);
                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.OKTypeFilter);
                FastDriver.NextGenDocumentRepository.OKTypeFilter.FAClick();

                //string TypeFilterenable = FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).Enabled.ToString();
                //Support.AreEqual("True", TypeFilterenable, "Type Filter Enabled");
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                //string typetooltip = FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).FAGetAttribute("Title");
                //Support.AreEqual("Filter set by : FAST QA07", typetooltip, "Type filter set by Automation User at order level");

                //Reports.TestStep = "Verify Clear Flter after filter enabled";
                //FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).FAClick();

                //MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")));

                FastDriver.NextGenDocumentRepository.TypeFilter.FARightClick();
                FastDriver.NextGenDocumentRepository.ClearFilter.FASelectContextMenuItem();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                    FastDriver.WebDriver.HandleDialogMessage();
                
                //Support.AreEqual("False", TypeFilterenable, "Type Filter is cleared after clear filter");

                #endregion
            }
            catch (Exception ex)
            {

                FailTest(GetExceptionInfo(ex));
            }
        }




        
        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();

        }

        public static void MouseHoverOnObject(IWebElement TargetElement)
        {

            string javaScript = "var evObj = document.createEvent('MouseEvents');" +
                                "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
                                "arguments[0].dispatchEvent(evObj);";
            IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;
               js.ExecuteScript(javaScript, TargetElement);
        }                        
        
    }
}