﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace NextGenDocPrep
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class NextGen_DPUC0008 : MasterTestClass
    {
        private static int regionId = 12837;
        private static int officeId = 12839;
        private SilverlightSupport FALibSL;

        #region NextGen_DPUC0008_BAT0001
        [TestMethod]
        public void NextGen_DPUC0008_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MainCourse: Select Data Element.";

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();

                Reports.TestStep = "Search for GOAL phrase group.";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.SelectPhraseType("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText("GOAL*");

                Reports.TestStep = "Click on Search button";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Right click the Phrase and select Add Phrase from context menu";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.PerformTableAction(1, 3, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.WaitCreation(FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_ContextMenu);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_AddPhrase.FASelectContextMenuItem();

                Reports.TestStep = "Click on Edit PhraseGroup tab";
                FastDriver.NextGenDocumentPreparation.WaitCreation(FastDriver.NextGenDocumentPreparation.DesPhrasesName);
               // FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTable);
               
                Reports.TestStep = "Select the Phrase and click on edit.";
                //FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction("Name", "PHR1", "Name", TableAction.Click);
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction("Name", "GOA1", "Name", TableAction.Click);
                
               
                //FALibHS.GetControl("ADM.PhraseGroupMaintenance", "Edit").Click();


                Reports.TestStep = "Click on Phrase Editor button.";
                //Playback.Wait(10000);
                //FALibHS.SetParent("ADM.PhraseMaintenance", "PhraseMaintenance");
                //FALibHS.GetControl("ADM.PhraseMaintenance", "PhraseEditor").Click();
                //Playback.Wait(2000);

                Reports.TestStep = "Click on Insert data element link after Move to end line.";
                //FALibHS.SetParent("ADM.PhraseEditorDlg", "PhraseEditorDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                //Keyboard.SendKeys("^{END}");
                //FALibHS.GetControl("ADM.PhraseEditorDlg", "InsertDataElement").Click();

                Reports.TestStep = "Direct Enter the Data Element name.";
                //Playback.Wait(10000);
                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("ADM.DataElementSelectionDlg", "DataElementSelectionDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                //FALibHS.GetControl("ADM.DataElementSelectionDlg", "DataElement").Set(HtmlEdit.PropertyNames.Text, @"HWLADD1");
                //Playback.Wait(10000);

                //// 
                //// 
                Reports.TestStep = "Click on Done in Dialog Box.";
                //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("BottomFrameDlg", "BottomFrameDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);

                //FALibHS.GetControl("BottomFrameDlg", "Done").Click();
                //Playback.Wait(10000);

                Reports.TestStep = "Click on Insert Data element Image button.";

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("ADM.PhraseEditorDlg", "PhraseEditorDlg");
                //FALibHS.GetControl("ADM.PhraseEditorDlg", "InsertDataElement").Click();

                Reports.TestStep = "Direct Enter the Data Element name.";
                //Playback.Wait(10000);
                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("ADM.DataElementSelectionDlg", "DataElementSelectionDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                //FALibHS.GetControl("ADM.DataElementSelectionDlg", "DataElement").Set(HtmlEdit.PropertyNames.Text, @"BSCONSTATE");
                //Playback.Wait(10000);

                //// 
                //// 
                Reports.TestStep = "Click on Done in Dialog Box.";
                //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("BottomFrameDlg", "BottomFrameDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);

                //FALibHS.GetControl("BottomFrameDlg", "Done").Click();
                //Playback.Wait(2000);
                //// 
                //// 
                Reports.TestStep = "Click on Save to save new data element.";
                //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("BottomFrameDlg", "BottomFrameDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);

                //FALibHS.GetControl("BottomFrameDlg", "Save").Click();
                //Playback.Wait(2000);
                //FALibHS.GetControl("BottomFrameDlg", "Done").Click();
                //Playback.Wait(10000);

                //FASTLibrary.FASTLibrary.PerformBottomFrameAction("Done");
                //Playback.Wait(2000);

                //Reports.TestStep = "Select the Phrase and click on edit.";
                //Playback.Wait(3000);
                //FALibHS.SetParent("ADM.PhraseGroupMaintenance", "PhraseGroupMaintenance");
                //FALibHS.m_errorMessage = "";
                //FATAF.General.value = FALibHS.HtmlTableSet("ADM.PhraseGroupMaintenance", "PhrasesTable", @"#1^PHR5^#2|Click").ToString();
                //if (FATAF.General.value == "False")
                //    General.Fail(FALibHS.m_errorMessage);
                //FALibHS.GetControl("ADM.PhraseGroupMaintenance", "Edit").Click();
                //Playback.Wait(2000);

                //Reports.TestStep = "Click on Phrase Editor button.";
                //Playback.Wait(10000);
                //FALibHS.SetParent("ADM.PhraseMaintenance", "PhraseMaintenance");
                //FALibHS.GetControl("ADM.PhraseMaintenance", "PhraseEditor").Click();
                //Playback.Wait(2000);

                //Reports.TestStep = "Click on Insert data element link after Move to end line.";
                //Playback.Wait(10000);
                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("ADM.PhraseEditorDlg", "PhraseEditorDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                //Playback.Wait(2000);
                //Keyboard.SendKeys("^{END}");
                //Playback.Wait(5000);
                //FALibHS.GetControl("ADM.PhraseEditorDlg", "InsertDataElement").Click();

                //Reports.TestStep = "Direct Enter the Data Element name.";
                //Playback.Wait(10000);
                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("ADM.DataElementSelectionDlg", "DataElementSelectionDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                //FALibHS.GetControl("ADM.DataElementSelectionDlg", "DataElement").Set(HtmlEdit.PropertyNames.Text, @"BUSIGN,BUSIGNSTK,SESIGN,SESIGNSTK");
                //Playback.Wait(10000);
                //// 
                //// 
                //Reports.TestStep = "Click on Done in DataElementSelection Dialog Box.";
                //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("BottomFrameDlg", "BottomFrameDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);

                //FALibHS.GetControl("BottomFrameDlg", "Done").Click();
                //Playback.Wait(10000);

                //// 
                //// 

                //Reports.TestStep = "Click on in Editor Save to save new data element.";
                //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;

                //FALibHS.IsDialog = true;
                //FALibHS.SetParent("BottomFrameDlg", "BottomFrameDlg");
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);

                //FALibHS.GetControl("BottomFrameDlg", "Save").Click();
                //Playback.Wait(2000);
                //FALibHS.GetControl("BottomFrameDlg", "Done").Click();
                //Playback.Wait(10000);
                //FASTLibrary.FASTLibrary.PerformBottomFrameAction("Done");

















            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion












        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}