﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace NextGenDocPrep.r00._2017.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_922232 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {


            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        [TestMethod]
        public void TC_939617()
        {
            try
            {
                //Template Editor Phrase Search from ADM and Document View Phrase Search from IIS to be automated with below scenarios  

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestDescription = "Verify the creation of Phrase with Keyword having combination of Alphanumeric and space as input and search for same in Phrase Search Dlg";

                Reports.TestStep = "Login to FAST Application Admin Side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation").WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "clicks on the Phrases Tab. ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Reports.TestStep = "Create New PhraseGroup";
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                Reports.TestStep = "enter a unique 4-character name for the new phrase group.";
                string randomName = RandomString(4);
                string randomName_1 = RandomString(4).ToUpper();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                Reports.TestStep = "select phrase type.";
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                Reports.TestStep = "User enters a description.";
                var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                Reports.TestStep = "Adding a New phrase";
                if (FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                if (FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                string RandomsName_NEW1 = RandomString(4).ToUpper();

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");

                Reports.TestStep = "Enter a keyword separated with comma and space";
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FASetText("        Akshay Kumar,    AshaRani");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                Reports.TestStep = "click on EditPhraseGroup";
                if (FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseContextMenu.FAFindElement(ByLocator.ClassName, "editPhrase").FASelectContextMenuItem();
                Reports.TestStep = "Verify the Saved Phrase Keyword";
                Support.AreEqual("Akshay Kumar,AshaRani", FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseKeyword.FAGetValue().ToString(), "Keyword value Saved successfully by removing the extra preceeding space");

                Reports.TestStep = "Create a new template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                
                Reports.TestStep = "Enter a Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Akshay K*,Asha*");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();             

                Reports.TestDescription = "Verify the Phrase Search with Keyword in IIS";

                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Click on Phrase View tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Right click and select insert Phrase";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.AddPhraseBelowInPhraseView();
               
                Reports.TestStep = "Enter Valid Phrase Keyword";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Keyword.FASetText("Akshay K*,Asha*");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                Playback.Wait(5000);

                Support.AreEqual("True", FastDriver.PhraseSelectDlg.ResultsTable.FeeExistOnTable(RandomsName_NEW1).ToString());

                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }



        }
     
        public string RandomString(int Size)
        {
            //string input = "abcdefghijklmnopqrstuvwxyz0123456789";
            //StringBuilder builder = new StringBuilder();
            //char ch;
            Random rand = new Random();

            string Alphabet = "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] chars = new char[Size];
            for (int i = 0; i < Size; i++)
            {
                chars[i] = Alphabet[rand.Next(Alphabet.Length)];
            }
            return new string(chars);


        }

        public int SearchExistingTemplate(string temptype, string tempdesc)
        {

            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(temptype);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempdesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            Playback.Wait(5000);
            int table_rows = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetRowCount();

            return table_rows;
        }


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}