﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class FilterTemplates : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();               
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }


        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        #region TestCase-All Templates Filtered Scenarios Verification

        [TestMethod]
        public void TestCase_AllTemplates()
        {
            Reports.TestDescription = "Verify All Templates Filtered Scenarios";

            #region Data Setup
           

            #endregion


            try
            {
                Reports.TestStep = "Login to FAST Application";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Naviagte to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                Reports.TestStep = "Change Template Search to blank if any primary filter is selected by default";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);

                #region Scenario1
                Reports.TestStep = "Verify template filtering for All Templates as search scope and Individual Template type and WITHOUT template description and with default filters as Corporate& Region and CA";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if(FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                var template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");


                #endregion

                #region Scenario2
                Reports.TestStep = "Verify template filtering for All Templates as search scope and Individual Template type and WITH template description and with default filters as Corporate& Region and CA";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("FILTER-1");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion

                #region Scenario3
                Reports.TestStep = "Verify template filtering for All Templates as search scope and Individual Template type and WITH template description and with default filters as Corporate& Region and State as ALL";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("FILTER-1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion

                #region Scenario4
                Reports.TestStep = "Verify template filtering for All Templates as search scope and Individual Template type and WITH OUT  template description and with default filters as Corporate& Region and State as ALL";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion

                #region Scenario5
                Reports.TestStep = "Verify template filtering for All Templates as search scope and All Template type and WITHOUT template description and with default filters as Corporate& Region and CA";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");


                #endregion

                #region Scenario6
                Reports.TestStep = "Verify template filtering for All Templates as search scope and All Template type and WITH template description and with default filters as Corporate& Region and CA";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("FILTER-1");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion

                #region Scenario7
                Reports.TestStep = "Verify template filtering for All Templates as search scope and All Template type and WITH template description and with default filters as Corporate& Region and State as ALL";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("FILTER-1");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion

                #region Scenario8
                Reports.TestStep = "Verify template filtering for All Templates as search scope and All Template type and WITH OUT  template description and with default filters as Corporate& Region and State as ALL";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait..", true, 10);
                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    Playback.Wait(3000);
                }

                template = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "FILTER-1", "Description", TableAction.GetText).Message;
                Support.AreEqual("FILTER-1", template, "Template is filtered as expected");

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Private methods

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
