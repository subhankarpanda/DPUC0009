﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;
using FASTSelenium.ImageRecognition;

namespace NextGenDocPrep
{
   [CodedUITest]
   public  class IR_Sample_DE : MasterTestClass 
    {
        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

       [TestMethod]
       [Description("Name Test case ")]
       [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
       public void Name_Test_case()
       {
           try
           {
               IRConfig.canSaveScreenSamples = true;
               IRConfig.saveAllSamples = true;
               Reports.TestDescription = "Description";

               #region DataSetup
               var credentials = new Credentials()
               {
                   UserName = AutoConfig.UserName,
                   Password = AutoConfig.UserPassword
               };
               #endregion

               #region Login to FAST Application File Side
               Reports.TestStep = "Login to FAST Application File Side";
               FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

               Reports.TestStep = "Navigate to Select Office screen";
               FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

               Reports.TestStep = "Navigate to NextGen Region/Office Level";
               FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
               var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
               if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                   throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
               #endregion

               #region CreateFile
               string fileNumber = "";
               try
               {
                   Reports.TestStep = "Create File using web service.";
                   var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                   nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                   nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                   nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                   nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                   nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                   nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                   fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                   FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
               }
               catch //If not able to create file via web service, create file via FAST GUI
               {
                   Reports.TestStep = "Create File using FAST GUI.";
                   FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                   try
                   {
                       FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                   }
                   catch
                   {
                       Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                   }

                   FastDriver.QuickFileEntry.CreateStandardFile();
                   FastDriver.TopFrame.SwitchToTopFrame();
                   FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                   fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
               }
               #endregion

               #region  Navigate to Document Repository Screen
               Reports.TestStep = "Navigate to Document Repository Screen";
               FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

               FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
               Playback.Wait(3000);
               #endregion


               #region Perform Right Click on a table row using Document Name
               Reports.TestStep = "Perform Right Click on a table row using Document Name";
               FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(2, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
               FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
               #endregion

               #region Perform Right Click View/Edit Document Created
               Reports.TestStep = "Perform Right Click View/Edit Document Created ";
               FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               //FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment", false);
               #endregion

               #region Template Sample
               Reports.TestStep = "Template sample";
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               //FastDriver.DocumentEditor.IRInsertPhraseArrowWhite.FARightClick();
               //FastDriver.DocumentEditor.PhraseInsertAboveTemplate();
               //FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
               //FastDriver.TemplateSelectionDlg.TemplateType.FASelectItem("Title Reports");
               //FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FAClick();
               //FastDriver.DialogBottomFrame.ClickDone();
               //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);               
               //FastDriver.DocumentEditor.WaitForScreenToLoad();
               FastDriver.DocumentEditor.IRTemplatePhraseType.FAClick();
              // FastDriver.DocumentEditor.Numbering_icon.FAClick();
               



               FastDriver.DocumentEditor.SaveAndClose();

                  

              // FastDriver.DocumentEditor.IRToolsDownArrow2.DelayOnce(5).FAClick();

               //FastDriver.DocumentEditor.IRDocumentCurrentLine.DelayOnce(2).FAClick();
              // FastDriver.DocumentEditor.IRDocumentCurrentLine.DelayOnce(2).FASendKeys("1254");
               //FastDriver.DocumentEditor.IRDocDeliveryDropDown.DelayOnce(2).Highlight();
               //FastDriver.DocumentEditor.IRDocDeliveryDropDown.DelayOnce(2).FAClick();
               //FastDriver.DocumentEditor.IRSave.DelayOnce(5).FAClick();


               #endregion





           }
           catch (Exception ex)
           {
               FailTest(GetExceptionInfo(ex));
           }
       }
       
       [ClassCleanup]

       public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}
