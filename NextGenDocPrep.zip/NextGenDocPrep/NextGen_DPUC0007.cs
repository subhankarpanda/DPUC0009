﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;
 

namespace NextGenDocPrep
{
    
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class NextGen_DPUC0007 : FASTHelpers
    {
        private static int _regionId = 12837;
        private static int _officeId = 12839;

        
        #region REG0001_MC

        [TestMethod]
        [Description("Main Course 1: Add New Template")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0001_MC()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();                
               
                Reports.TestDescription = "Main Course 1: Add New Template";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate to NextGen Document Preparation Screen and create a Template (DP8180,DP8182)
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch101", "Escrow Instruction");  
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        #endregion
        
        #region REG0002_MC
        [TestMethod]
        [Description("Main Course 2: Search Template")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0002_MC()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();    

                Reports.TestDescription = "Main Course 2: Search Template / Alternate Course 1: Edit Template";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search template(DP8177)
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");                
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Modify Template Type, Template Description.
                Reports.TestStep = "Verify Template Name is not editable";
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.TemplateDescription.IsEnabled().ToString(), false);              
                
                Reports.TestStep = "Modify Template Type";
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                Reports.TestStep = "Modify Template Description";
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("NEXTGEN_SAN_Endorsement_DoNotTouch" + FAKeys.Tab);

                Reports.TestStep = "Enter comments in Revision History Table.";
                FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test_Comment1234"+FAKeys.Tab);
                string strComments = FastDriver.NextGenDocumentPreparation.Template_Comment.FAGetValue();                
                #endregion

                #region Validate Notification Attachment Candidate check box and Select
                Reports.TestStep = "Validate Notification Attachment Candidate check box and Select";
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.NotificationCandidate.IsVisible().ToString() , true);
                FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(true);                            
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Verify if the system saves the template modifications and captures the revision history (Revision date, Revised by, Status and Comments).
                string strComment = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Comments", TableAction.Click).Element.FAGetText(); 

                Reports.TestStep = "Verify Revised Date.";                
                DateTime today = DateTime.Today; // As DateTime
                string strRevisedDate = today.ToString("MM/dd/yyyy");
                string strRevisedDate1 = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Revised Date", TableAction.Click).Element.FAGetText();
                Support.AreEqual(strRevisedDate, strRevisedDate1, true);

                Reports.TestStep = "Verify Revised By.";
                string strRevisedBy = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Revised By", TableAction.Click).Element.FAGetText();
                string strRevisedBy1 = "FASTTS" + "\\"  + "FASTQA07";
                Support.AreEqual(strRevisedBy1, strRevisedBy, true);

                Reports.TestStep = "Verify Status.";
                string strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Active", strStatus, true);
                Reports.TestStep = "Verify Comments.";                
                Support.AreEqual(strComments, strComment, true);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);
                #endregion

                #region Click on Template Filtering tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0001_AC
        [TestMethod]
        [Description("Alternate Course 1: Edit Template")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0001_AC()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Main Course 2: Search Template / Alternate Course 1: Edit Template";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Modify Template Type, Template Description.
                Reports.TestStep = "Verify Template Name is not editable";
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.TemplateDescription.IsEnabled().ToString(), false);

                Reports.TestStep = "Modify Template Type";
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                Reports.TestStep = "Modify Template Description";
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("NEXTGEN_SAN_Endorsement_DoNotTouch" + FAKeys.Tab);

                Reports.TestStep = "Enter comments in Revision History Table.";
                FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test_Comment1234" + FAKeys.Tab);
                string strComments = FastDriver.NextGenDocumentPreparation.Template_Comment.FAGetValue();
                #endregion

                #region Validate Notification Attachment Candidate check box and Select
                Reports.TestStep = "Validate Notification Attachment Candidate check box and Select";
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.NotificationCandidate.IsVisible().ToString(), true);
                FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Verify if the system saves the template modifications and captures the revision history (Revision date, Revised by, Status and Comments).
                string strComment = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Comments", TableAction.Click).Element.FAGetText();

                Reports.TestStep = "Verify Revised Date.";
                DateTime today = DateTime.Today; // As DateTime
                string strRevisedDate = today.ToString("MM/dd/yyyy");
                string strRevisedDate1 = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Revised Date", TableAction.Click).Element.FAGetText();
                Support.AreEqual(strRevisedDate, strRevisedDate1, true);

                Reports.TestStep = "Verify Revised By.";
                string strRevisedBy = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Revised By", TableAction.Click).Element.FAGetText();
                string strRevisedBy1 = "FASTTS" + "\\" + "FASTQA07";
                Support.AreEqual(strRevisedBy1, strRevisedBy, true);

                Reports.TestStep = "Verify Status.";
                string strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Active", strStatus, true);
                Reports.TestStep = "Verify Comments.";
                Support.AreEqual(strComments, strComment, true);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);
                #endregion

                #region Click on Template Filtering tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0002_AC
        [TestMethod]
        [Description("Alternate Course 2: Copy Templates")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0002_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2: Copy Templates";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on Copy Template Option (DP8178)
                Reports.TestStep = "Select a Template and right click for Copy Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion
                
                #region Format the properties and click on Save
                Reports.TestStep = "Format the properties and click on Save";
                // FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                Reports.TestStep = "Edit Template Name";
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("SAN-NEXTGEN203");
                Reports.TestStep = "Edit Template Type";
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                Reports.TestStep = "Edit Template Description";
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch");
                string templateDesc = FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FAGetText(); 
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();

                #region Verify the formatting options in "Ad-hoc Phrase Settings"(DP8159, DP8160)
                Reports.TestStep = "Verify the formatting optioans in \"Ad-hoc Phrase Settings\"";
                Support.AreEqual("Tahoma", FastDriver.NextGenDocumentPreparation.Template_Information_FontName.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("10", FastDriver.NextGenDocumentPreparation.Template_Information_FontSize.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.21", FastDriver.NextGenDocumentPreparation.Template_Information_TopMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.7", FastDriver.NextGenDocumentPreparation.Template_Information_LeftMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.8", FastDriver.NextGenDocumentPreparation.Template_Information_RightMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.Template_Information_PageType.IsSelected().ToString(), true);
                #endregion

                #region Click on Template Save button and Save the changes
                Reports.TestStep = "Click on Template Save button and Save the changes";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Create phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("EN06/1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Verify newly generated Template ID
                Reports.TestStep ="Verify newly generated Template ID";
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight(5);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.VersioningTemplate.Exists().ToString(), true);     


                #endregion


                #region Verify if the system saves the template modifications and captures the revision history (Revision date, Revised by, Status and Comments).

                FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                string strComments = "Created";
                string strComment = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Comments", TableAction.Click).Element.FAGetText();

                Reports.TestStep = "Verify Revised Date.";
                DateTime today = DateTime.Today; // As DateTime
                string strRevisedDate = today.ToString("MM/dd/yyyy");
                string strRevisedDate1 = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComments, "Revised Date", TableAction.Click).Element.FAGetText();
                Support.AreEqual(strRevisedDate, strRevisedDate1, true);

                Reports.TestStep = "Verify Revised By.";
                string strRevisedBy = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Revised By", TableAction.Click).Element.FAGetText();
                string strRevisedBy1 = "FASTTS" + "\\" + "FASTQA07";
                Support.AreEqual(strRevisedBy1, strRevisedBy, true);

                Reports.TestStep = "Verify Status.";
                string strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", strComment, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Active", strStatus, true);
                Reports.TestStep = "Verify Comments.";
                Support.AreEqual(strComments, strComment, true);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        #endregion

        #region REG0003_AC
        [TestMethod]
        [Description("Alternate Course 3: Deactivate Template (Only for active templates)")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0003_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2: Copy Templates";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on Copy Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion
                #region Deactivate the Template and Save (DP8170,DP8172)
                Reports.TestStep = "Deactivate the Template and Save";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                // FastDriver.WebDriver.HandleDialogMessage(true);
                // FastDriver.NextGenDocumentPreparation.Save.FAClick(); 
                FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                DateTime today = DateTime.Today; // As DateTime
                string strRevisedDate = today.ToString("MM/dd/yyyy");
                string strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Revised Date", strRevisedDate, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Inactive", strStatus, true);
                #endregion

                //#region Activate the Template and Save
                //Reports.TestStep = "Activate the Template and Save";
                //FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                //// FastDriver.WebDriver.HandleDialogMessage(true);
                //// FastDriver.NextGenDocumentPreparation.Save.FAClick(); 
                //FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test");
                //FastDriver.NextGenDocumentPreparation.Save.FAClick();

                //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                //strStatus = "";
                //strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Revised Date", strRevisedDate, "Status", TableAction.Click).Element.FAGetText();
                //Support.AreEqual("Inactive", strStatus, true);
                //#endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region REG0004_AC
        [TestMethod]
        [Description("Alternate Course 4: Activate Template (Only for inactive templates)")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0004_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2: Copy Templates";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on Copy Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";




                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion
                #region Activate the Template and Save(DP8171,DP8173,DP8174)
                Reports.TestStep = "Deactivate the Template and Save";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                // FastDriver.WebDriver.HandleDialogMessage(true);
                // FastDriver.NextGenDocumentPreparation.Save.FAClick(); 
                FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                DateTime today = DateTime.Today; // As DateTime
                string strRevisedDate = today.ToString("MM/dd/yyyy");
                string strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Revised Date", strRevisedDate, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Inactive", strStatus, true);
                #endregion

                #region Activate the Template and Save
                Reports.TestStep = "Activate the Template and Save";
                FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                // FastDriver.WebDriver.HandleDialogMessage(true);
                // FastDriver.NextGenDocumentPreparation.Save.FAClick(); 
                FastDriver.NextGenDocumentPreparation.Template_Comment.FASetText("Test");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                strStatus = "";
                strStatus = FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Revised Date", strRevisedDate, "Status", TableAction.Click).Element.FAGetText();
                Support.AreEqual("Inactive", strStatus, true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion
 
        #region REG0005_AC
        [TestMethod]
        [Description("Alternate Course 5: Enter Adhoc Phrase settings")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0005_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2: Copy Templates / Alternate Course 5: Enter Adhoc Phrase settings";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on Copy Template Option
                Reports.TestStep = "Select a Template and right click for Copy Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Format the properties and click on Save
                Reports.TestStep = "Format the properties and click on Save";
                // FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                Reports.TestStep = "Edit Template Name";
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("SAN-NEXTGEN203");
                Reports.TestStep = "Edit Template Type";
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                Reports.TestStep = "Edit Template Description";
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch");
                string templateDesc = FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FAGetText();
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();

                #region Verify the formatting optioans in "Ad-hoc Phrase Settings"
                Reports.TestStep = "Verify the formatting optioans in \"Ad-hoc Phrase Settings\"";
                Support.AreEqual("Tahoma", FastDriver.NextGenDocumentPreparation.Template_Information_FontName.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("10", FastDriver.NextGenDocumentPreparation.Template_Information_FontSize.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.21", FastDriver.NextGenDocumentPreparation.Template_Information_TopMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.7", FastDriver.NextGenDocumentPreparation.Template_Information_LeftMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("0.8", FastDriver.NextGenDocumentPreparation.Template_Information_RightMargin.FAGetSelectedItem().ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.Template_Information_PageType.IsSelected().ToString(), true);
                #endregion

                #region Click on Template Save button and Save the changes
                Reports.TestStep = "Click on Template Save button and Save the changes";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

                #endregion
        #endregion

        #region REG0006_AC
        [TestMethod]
        [Description("Alternate Course 6: Add Phrase")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0006_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 6: Add Phrase";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Create phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("EN06/1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();  
                #endregion


                #region Edit phrase from the template phrases tab
                Reports.TestStep = "Edit phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[1]);
               // FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                //FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
               // FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
               // FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesFormName.FASelectItem("1099-S-CA");
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesSectionBrkDone.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                #endregion
                #region Verify the edited phrase is displayed in Template Phrase Table
                Reports.TestStep = "Verify the edited phrase is displayed in Template Phrase Table";
                string strEditedPhraseName = FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("True", strEditedPhraseName.Contains("1099-S-CA").ToString() , true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion


                
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0007_AC(DP8186)
        [TestMethod]
        [Description("Alternate Course 7: Edit Phrase")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0007_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 7: Edit Phrase";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Create phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("EN06/1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion


                #region Edit phrase from the template phrases tab
                Reports.TestStep = "Edit phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[1]);
                // FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                //FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                // FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                // FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesFormName.FASelectItem("1099-S-CA");
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesSectionBrkDone.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                #endregion
                #region Verify the edited phrase is displayed in Template Phrase Table
                Reports.TestStep = "Verify the edited phrase is displayed in Template Phrase Table";
                string strEditedPhraseName = FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("True", strEditedPhraseName.Contains("1099-S-CA").ToString(), true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion



            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0008_AC_PhraseCondition_ErrMSG
        [TestMethod]
        [Description("Alternate Course 8: Phrase Conditioning / Handling Error Message")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0008_AC_PhraseCondition_ErrMSG()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 8: Phrase Conditioning / / Handling Error Message";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Create phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("EN06/1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion


                #region Select a phrase and click on Template View button
                Reports.TestStep = "Select a phrase and click on Template View button";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, 2, TableAction.Click).Element.FAClick();                          
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                FastDriver.NextGenDocumentPreparation.InsertPhraseCondition();
                
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0009_AC
        [TestMethod]
        [Description("Alternate Course 9: Add Template Filtering Criteria")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0009_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 9: Add Template Filtering Criteria / Alternate Course 10: Add Role Type/Business Party combination filter criteria";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                #endregion

                #region Click Filtering TAB Select All Select options (DP8176)
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();


                    #region Add Role Type/Business Party combination filter criteria
                    Reports.TestStep = "Add Role Type/Business Party combination filter criteria";

                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("BOA");
                    string NameIDC = FastDriver.NextGenDocumentPreparation.NameIdCode.FAGetText();
                    #region Click on Find Name Button and Verify the GAB
                    Reports.TestStep = "Click on Find Name Button and Verify the GAB";  
                    FastDriver.NextGenDocumentPreparation.FindName.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "Boardwalk Mortgage", "Address", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    FastDriver.BottomFrame.Done();
                    #endregion

                    #region Click on Find Code Button and Verify the Name or ID Code is added in Business Party
                    Reports.TestStep = "Click on Find Code Button and Verify the Name or ID Code is added in Business Party";
                    FastDriver.NextGenDocumentPreparation.FindCode.FAClick();

                    string BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True",BusinessParty.Contains(NameIDC).ToString() ,true); 
                    #endregion


                    #region Click on Search Button to search for a Business Party to populate into the Business Party list box
                    Reports.TestStep = "Click on Search Button to search for a Business Party to populate into the Business Party list box";
                    FastDriver.NextGenDocumentPreparation.Search1.FAClick();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.BusinessOrgSearchDlg.EntityType.FASelectItem("Attorney");  
                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true);
   
                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Select", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    string BusinessName = FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Name", TableAction.GetCell).Element.FAGetText();                     
                    
                    FastDriver.BottomFrame.Done();
                    Reports.TestStep = "Verify Business Party to populate into the Business Party list box";
                    BusinessParty = "";
                    BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True", BusinessParty.Contains(BusinessName).ToString(), true);              
                    #endregion


                    #region Verify Cancel, Done buttons are enabled
                    Reports.TestStep = "Verify Cancel, Done buttons are enabled.";
                    Support.AreEqual("True", FastDriver.GeograficFilterSelectionDlg.CancelButton.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.GeograficFilterSelectionDlg.DoneButton.IsEnabled().ToString(), true);


                    #endregion
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    #endregion




                    
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion    
                
                
                // CloseRelatedProcesses();

                

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0010_AC
        [TestMethod]
        [Description("Alternate Course 10: Add Role Type/Business Party combination filter criteria")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0010_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 10: Add Role Type/Business Party combination filter criteria";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();

                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();


                    #region Add Role Type/Business Party combination filter criteria
                    Reports.TestStep = "Add Role Type/Business Party combination filter criteria";

                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("BOA");
                    string NameIDC = FastDriver.NextGenDocumentPreparation.NameIdCode.FAGetText();
                    #region Click on Find Name Button and Verify the GAB
                    Reports.TestStep = "Click on Find Name Button and Verify the GAB";
                    FastDriver.NextGenDocumentPreparation.FindName.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "Boardwalk Mortgage", "Address", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    FastDriver.BottomFrame.Done();
                    #endregion

                    #region Click on Find Code Button and Verify the Name or ID Code is added in Business Party
                    Reports.TestStep = "Click on Find Code Button and Verify the Name or ID Code is added in Business Party";
                    FastDriver.NextGenDocumentPreparation.FindCode.FAClick();

                    string BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True", BusinessParty.Contains(NameIDC).ToString(), true);
                    #endregion


                    #region Click on Search Button to search for a Business Party to populate into the Business Party list box
                    Reports.TestStep = "Click on Search Button to search for a Business Party to populate into the Business Party list box";
                    FastDriver.NextGenDocumentPreparation.Search.FAClick();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.BusinessOrgSearchDlg.EntityType.FASelectItem("Attorney");
                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true);

                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Select", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    string BusinessName = FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Name", TableAction.GetCell).Element.FAGetText();

                    FastDriver.BottomFrame.Done();
                    Reports.TestStep = "Verify Business Party to populate into the Business Party list box";
                    BusinessParty = "";
                    BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True", BusinessParty.Contains(BusinessName).ToString(), true);
                    #endregion
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    #endregion





                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion


                // CloseRelatedProcesses();



            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0011_AC
        [TestMethod]
        [Description("Alternate Course 11: Edit Template Filter")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0011_AC()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 11: Edit Template Filter";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                //#region Navigate to NextGen Document Preparation Screen
                //Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                //FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                //#endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {



                    #region Click on "Edit Filter" Icon

                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);


                    //Reports.TestStep = "Click on \"Edit Filter\" Icon";
                    //var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group
                    //EditFilter.FAClick();
                    //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                    #endregion

                    #region Edit one or more of the filter criteria
                    Reports.TestStep = "Edit one or more of the filter criteria";
                    //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();

                   // FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();                   
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    #endregion


                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG00012_Error_Message
        [TestMethod]
        [Description("Template Error and Warning Messages")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG00012_Error_Message()
        {
            try
            {
                Reports.TestDescription = "Template Error and Warning Messages";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on Copy Template Option
                Reports.TestStep = "Select a Template and right click for Copy Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Verify error message with same template name in another templated type in the same region (DP8149,DP8179)
                Reports.TestStep = " Verify error message with same template name in another templated type in the same region";
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("Escrow-NXTGN11" + FAKeys.Tab);
                string strTempName = FastDriver.NextGenDocumentPreparation.TemplateName.FAGetText();
                string strTempMessage = "Template Name " + strTempName + " already exists. Please enter a new Name.";

                Reports.TestStep = "Select a Template Type";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");


                Reports.TestStep = "Click on Template Save button and Save the changes";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                Reports.TestStep = "Verify the error message thrown";
                FastDriver.WebDriver.HandleDialogMessage(true);
                string errMessage = FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.FAGetText();
                Support.AreEqual(strTempMessage, errMessage, true);
                #endregion


                #region Verify error message with a blank Template Name
                Reports.TestStep = " Verify error message with a blank Template Name";
                FastDriver.NextGenDocumentPreparation.TemplateName.Clear();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                Reports.TestStep = "Verify the error message thrown";
                string Message = "Template Name is required";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion


                #region Verify error message with special characters in Template Name(DP8151)
                Reports.TestStep = " Verify error message with special characters in Template Name";
                FastDriver.NextGenDocumentPreparation.TemplateName.Clear();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("ST0^!~"); 
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                Reports.TestStep = "Verify the error message thrown";
                Message = "";
                Message = "Name may only contain 0-9 a-z A-Z < > * % $ # : ; ‘ “ / + - = (  ) . , characters";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion



                #region Verify error message with special characters in Template Description
                Reports.TestStep = " Verify error message with special characters in Template Description";
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("Tem101");
                FastDriver.NextGenDocumentPreparation.TemplateDescr.Clear();
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("ST0^!~");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                Reports.TestStep = "Verify the error message thrown";
                Message = "";
                Message = "Description may only contain 0-9 a-z A-Z < > * % $ # : ; ‘ “ / + - = (  ) . , characters";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion



                #region Verify error message with top margin value greater than 7 (DP8156)
                Reports.TestStep = "Verify error message with top margin value greater than 7";
                
                FastDriver.NextGenDocumentPreparation.Template_Information_TopMargin.FASetText("8"+FAKeys.Tab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                int Margin = Convert.ToInt32(FastDriver.NextGenDocumentPreparation.Template_Information_TopMargin.FAGetText());
                if (Margin > 7)
                {
                    Reports.TestStep = "Verify the error message thrown";
                    Message = "";
                    Message = "Top Margin Value must be a number between 0 and 7";
                    FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                }           
                               
                #endregion


                #region Verify error message with left margin value greater than 7(DP8157)
                Reports.TestStep = "Verify error message with left margin value greater than 7";
                FastDriver.NextGenDocumentPreparation.Template_Information_LeftMargin.FASetText("8" + FAKeys.Tab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Margin = 0;
                Margin = Convert.ToInt32(FastDriver.NextGenDocumentPreparation.Template_Information_LeftMargin.FAGetText());
                if (Margin > 7)
                {
                    Reports.TestStep = "Verify the error message thrown";
                    Message = "";
                    Message = "Incorret Margin value. Valid values are decimals between 0.00 and 7.00 for each margine. Sum of a left and right margin should not exceed 8.5";
                    FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                }
                #endregion

                #region Verify error message with right margin value greater than 7(DP8158)
                Reports.TestStep = "Verify error message with right margin value greater than 7";
                FastDriver.NextGenDocumentPreparation.Template_Information_RightMargin.FASetText("8" + FAKeys.Tab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Margin = 0;
                Margin = Convert.ToInt32(FastDriver.NextGenDocumentPreparation.Template_Information_RightMargin.FAGetText());
                if (Margin > 7)
                {
                    Reports.TestStep = "Verify the error message thrown";
                    Message = "";
                    Message = "Incorret Margin value. Valid values are decimals between 0.00 and 7.00 for each margine. Sum of a left and right margin should not exceed 8.5";
                    FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                }
                #endregion


                #region Verify error message with “View” button to preview the template with under construction flag unchecked(DP8165)
                Reports.TestStep = "Verify error message with “View” button to preview the template with under construction flag unchecked";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                Reports.TestStep = "Click on Preview button";
                FastDriver.NextGenDocumentPreparation.SeachtemplateButton.FAClick();   

                Reports.TestStep = "Verify the error message thrown";
                Message = "";
                Message = "A template must be Under Construction to be previewed.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion


                #region Verify error message with previewing the template without saving the changes
                Reports.TestStep = "Verify error message with previewing the template without saving the changes";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Template_Information_RightMargin.FASetText("3" + FAKeys.Tab);
                Reports.TestStep = "Click on Preview button";
                FastDriver.NextGenDocumentPreparation.SeachtemplateButton.FAClick();
                Reports.TestStep = "Verify the error message thrown";
                Message = "";
                Message = "Please save your changes to this Template prior to Previewing.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion



                #region Verify warning message when User changes the status of a template flagged as a Notification Attachment Candidate to Inactive.
                Reports.TestStep = "Verify warning message when User changes the status of a template flagged as a Notification Attachment Candidate to Inactive.";
                FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Inactive.FAClick();  

                Reports.TestStep = "Verify the warning message thrown";
                Message = "";
                Message = "Inactivating this document template.  This document template will not be available for Notification attachment.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion



            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }
        #endregion
        
        #region REG00013_Filtering_ErrorMessage (DP8220)
        [TestMethod]
        [Description("Template Filtering Error/Warning Message and Condition.")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG00013_Filtering_ErrorMessage()
        {
            try
            {
                Reports.TestDescription = "Template Filtering Error/Warning Message and Condition.";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    Reports.TestStep = "You must select at least one Service Type.";
                    Support.AreEqual("You must select at least one Service Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());                                      
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();

                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    Reports.TestStep = "You must select at least one Transaction Type.";
                    Support.AreEqual("You must select at least one Transaction Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();

                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    Reports.TestStep = "You must select at least one Property Type.";
                    Support.AreEqual("You must select at least one Property Type.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());                                      
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();

                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();         
                   
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    #region Validate Find Name
                    Reports.TestStep = "Validate Find Name"; 
                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    Reports.TestStep = "Enter an invalid name in \"Name/ID Code\" field";
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("ras");
                    FastDriver.NextGenDocumentPreparation.FindName.FAClick();
                    Reports.TestStep = "Name not found.";
                    Support.AreEqual("Name not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    #endregion
                    #region Validate Find Code
                    Reports.TestStep = "Validate Find Code";
                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    Reports.TestStep = "Enter an invalid name in \"Name/ID Code\" field";
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("001");
                    FastDriver.NextGenDocumentPreparation.FindCode.FAClick();
                    Reports.TestStep = "ID Code not found.";
                    Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    #endregion

                    #region Validate Search
                    Reports.TestStep = "Validate Search";
                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    Reports.TestStep = "Enter an invalid name in \"Name/ID Code\" field";
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("wf");
                    FastDriver.NextGenDocumentPreparation.Search1.FAClick();
                    Reports.TestStep = "The Name/ID Code must be blank to access the Business Org Search feature";
                    Support.AreEqual("The Name/ID Code must be blank to access the Business Org Search feature", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    #endregion


                    #region Add Role Type/Business Party combination filter criteria
                    Reports.TestStep = "Add Role Type/Business Party combination filter criteria";

                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItem("New Loan");
                    FastDriver.NextGenDocumentPreparation.NameIdCode.FASetText("BOA");
                    string NameIDC = FastDriver.NextGenDocumentPreparation.NameIdCode.FAGetText();
                   
                    #region Click on Find Name Button and Verify the GAB
                    Reports.TestStep = "Click on Find Name Button and Verify the GAB";
                    FastDriver.NextGenDocumentPreparation.FindName.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);


                    #region
                    FastDriver.BusinessOrgSearchDlg.EntityName.Clear();
                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    Reports.TestStep = "User must provide Search Name to complete search.";                    
                    Support.AreEqual("User must provide Search Name to complete search.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    FastDriver.BusinessOrgSearchDlg.EntityName.FASetText("boa"); 
                    #endregion

                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "Boardwalk Mortgage", "Address", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    FastDriver.BottomFrame.Done();
                    #endregion

                    #region Click on Find Code Button and Verify the Name or ID Code is added in Business Party
                    Reports.TestStep = "Click on Find Code Button and Verify the Name or ID Code is added in Business Party";
                    FastDriver.NextGenDocumentPreparation.FindCode.FAClick();

                    string BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True", BusinessParty.Contains(NameIDC).ToString(), true);
                    #endregion


                    #region Click on Search Button to search for a Business Party to populate into the Business Party list box
                    Reports.TestStep = "Click on Search Button to search for a Business Party to populate into the Business Party list box";
                    FastDriver.NextGenDocumentPreparation.Search.FAClick();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.BusinessOrgSearchDlg.EntityType.FASelectItem("Attorney");
                    FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true);

                    FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Select", TableAction.GetElementFromTableCell, "input").Element.FAClick();
                    string BusinessName = FastDriver.BusinessOrgSearchDlg.ResultsTable.PerformTableAction("Name", "1222", "Name", TableAction.GetCell).Element.FAGetText();

                    FastDriver.BottomFrame.Done();
                    Reports.TestStep = "Verify Business Party to populate into the Business Party list box";
                    BusinessParty = "";
                    BusinessParty = FastDriver.NextGenDocumentPreparation.BusinessParty.FAGetText();
                    Support.AreEqual("True", BusinessParty.Contains(BusinessName).ToString(), true);
                    #endregion


                    #region User tries to delete one or more selected Business Parties and Validate the error message.
                    Reports.TestStep = "User tries to delete one or more selected Business Parties and Validate the error message";

                    FastDriver.NextGenDocumentPreparation.BusinessParty.FASelectItemByIndex(0);
                    FastDriver.NextGenDocumentPreparation.DeleteBusinessParty.FAClick();
                    Reports.TestStep = "Are you sure you want to delete selected Business parties?";
                    Support.AreEqual("Are you sure you want to delete selected Business parties?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                    #endregion
                    

                    #region User changes the role type to blank and Validate the warning message.
                    Reports.TestStep = "User changes the role type to blank and Validate the warning message";

                    FastDriver.NextGenDocumentPreparation.RoleType.FASelectItemByIndex(0);
                    Reports.TestStep = "“Replacing the selected Role Type with a Blank will delete all Business Parties that are saved in the Business Party listbox.";
                    Support.AreEqual("“Replacing the selected Role Type with a Blank will delete all Business Parties that are saved in the Business Party listbox.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                    
                    #endregion
                                       
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                    #endregion





                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion


                // CloseRelatedProcesses();



            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion  
        
        #region REG0014_Delete_Template
        [TestMethod]
        [Description("Delete Template")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0014_Delete_Template()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Delete Template";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                //FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();                
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
               
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                //FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction( 3, 1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.DeleteTemplate.FAClick();
                Playback.Wait(3000);
                #endregion


                #region Verify the Delete confirm message
                Reports.TestStep = "Verify the Delete confirm message.";                
                string Message = "";
                Message = "Do you want to delete the template?";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0015_NewSearch_Template
        [TestMethod]
        [Description("Functionality of New Search")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0015_NewSearch_Template()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Functionality of New Search";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");

                #endregion

                #region Click on New Search Button
                Reports.TestStep = "Click on New Search Button";

                FastDriver.NextGenDocumentPreparation.TemplateNewSearch.FAClick(); 
                             
                #endregion


                #region Verify if it Clears all entered or selected information from both the Template Search Criteria and the Search Results sections of the screen
                Reports.TestStep = "Verify if its Clears all entered or selected information from both the Template Search Criteria and the Search Results sections of the screen.";

                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.IsVisible().ToString(), false);
                Support.AreEqual("Template Description", FastDriver.NextGenDocumentPreparation.TemplateDescription.FAGetText(), true); 

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0016_CPL_Error_Message

        [TestMethod]
        [Description("Error Message for CPL Template Type")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0016_CPL_Error_Message()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Error Message for CPL Template Type";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate to NextGen Document Preparation Screen and create a Template
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";                
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template with Template Type = CPL";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText("TempCPL");
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Test Template CPL");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("CPL");                                              
                #endregion



                #region Verify error message
                Reports.TestStep = "Verify the error message thrown";
                string Message = "";
                Message = "CPL document type can be used only from Docprep Region.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion
                


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0017_Delete_Filter
        [TestMethod]
        [Description("Delete Template Filtering. DP8244")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0017_Delete_Filter()
        {
            try
            {
                Reports.TestDescription = "Delete Template Filtering";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Search Template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
               

                #region Click Filtering TAB 
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);

                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.DeleteFilter.FAClick();


                    #region Verify the Dlete confirm message
                    Reports.TestStep = "Verify the Dlete confirm message";
                    string Message = "";
                    Message = "Filter Group will be deleted. Do you want to continue?";
                    FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                    #endregion
                    
                   
                }
                
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG00018_TemplateType_Status(DP8153)
        [TestMethod]
        [Description("Template type status for Title Report, Lenders Policy, and Owners Policy")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG00018_TemplateType_Status()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Template type status for Title Report, Lenders Policy, and Owners Policy";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion


                #region Search Title Reports template type
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Title Reports", "NEXTGEN_SAN_TitleReports_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Verify Template Type is enabled or disable
                Reports.TestStep = "Verify Template Type is enabled or disabled";
                string TemptypeStatus = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.IsEnabled().ToString();
                Support.AreEqual("False", TemptypeStatus, false);

                #endregion

                #region Search Lender Policy template type
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Lender Policy", "NEXTGEN_SAN_LenderPolicy_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Verify Template Type is enabled or disable.
                Reports.TestStep = "Verify Template Type is enabled or disabled";
                TemptypeStatus = "";
                TemptypeStatus = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.IsEnabled().ToString();
                Support.AreEqual("False", TemptypeStatus, false);

                #endregion


                #region Search Lender Policy template type
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Owner Policy", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Verify Template Type is enabled or disabled.
                Reports.TestStep = "Verify Template Type is enabled or disabled";
                TemptypeStatus = "";
                TemptypeStatus = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.IsEnabled().ToString();
                Support.AreEqual("False", TemptypeStatus, false);
                #endregion


                #region Search template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Verify Template Type is enabled or disabled.
                Reports.TestStep = "Verify Template Type is enabled or disabled";
                TemptypeStatus = "";
                TemptypeStatus= FastDriver.NextGenDocumentPreparation.TemplateType_Properties.IsEnabled().ToString();
                Support.AreEqual("True", TemptypeStatus, true);  
               
                #endregion

               
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion
        
        #region REG0019_Phrase_ErrorMessage
        [TestMethod]
        [Description("Template Phrase Error/Warning Message")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0019_Phrase_ErrorMessage()
        {
            try
            {
                Reports.TestDescription = "Template Phrase Error/Warning Message";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Create phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();
                #endregion

                #region Validate error message entering invalid phrase code/name in phrase name text box of phrase selection dialog and clicks on Done button
                Reports.TestStep = "Validate error message entering invalid phrase code/name in phrase name text box of phrase selection dialog and clicks on Done button.";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("/TestPhrase");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Verify error message
                Reports.TestStep = "Verify the error message thrown";
                string Message = "";
                Message = "/TestPhrase not a valid phrase, please correct.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion

                #region Select any phrase from Phrase selection dialogbox
                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText("EN06/1");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region
                Reports.TestStep = "Edit Template Description in Template Properties tab and switch to Template Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Test Phrase Template");
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                #endregion


                #region Edit phrase from the template phrases tab
                Reports.TestStep = "Edit phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrase.FAClick();
                #endregion


                #region Verify error message
                Reports.TestStep = "Verify the error message thrown";
                Message = "";
                Message = "You have made changes to this template. You must save your changes before you can edit this phrase.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion
                
              }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0020_DataElement_ErrorMessage

        [TestMethod]
        [Description("Data Element ErrorMessage")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0020_DataElement_ErrorMessage()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Data Element ErrorMessage";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
              

                var groupName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);

                var groupDescription = "TEST--" + Support.RandomString("ANAN".Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString("ANAN".Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement_ErrorMessage();                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0021_Notification_Attachment_Candidate_ErrorMessage
        [TestMethod]
        [Description("Notification Attachment Candidate ErrorMessage")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0021_Notification_Attachment_Candidate_ErrorMessage()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Notification Attachment Candidate Error Message";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Endorsement Guarantee", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                
                #region Select Notification Attachment Candidate check box
                Reports.TestStep = "Select Notification Attachment Candidate check box";               
                FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Navigate to System Maintenance>Process Setup>Task Templates
                Reports.TestStep = "Navigate to System Maintenance>Process Setup>Task Templates";
                FastDriver.TaskTemplateSelection.Open();
                FastDriver.TaskTemplateSelection.SwitchToContentFrame();            
                #endregion

                #region Select Task Categories
                Reports.TestStep = "Select Task Categories";
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, "Title", 3, TableAction.Click);
                Playback.Wait(2000);
                #endregion
                
                #region Select Task Categories
                FastDriver.TaskTemplateSelection.New.FAClick();
                string taskName = Support.RandomString("AAZZ");
                int lastRow = FastDriver.TaskTemplateSelection.TasksForTable.FindElements(By.CssSelector("tr")).Count - 1;
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(lastRow, 3, TableAction.SetText, taskName);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                #endregion

                #region Select the newly created Task
                Reports.TestStep = "Select the newly created Task.";
                FastDriver.TaskTemplateSelection.SwitchToContentFrame();
                Playback.Wait(2000);          
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, "Title", 3, TableAction.Click);
                Playback.Wait(1000);

                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, taskName, 3, TableAction.Click);
                Playback.Wait(1000);
                #endregion

                #region Click on Notification Button
                Reports.TestStep = "Click on 'Notification' button";
                FastDriver.TaskTemplateSelection.Notification.FAClick();
                FastDriver.NotificationSummary.SwitchToContentFrame();
                #endregion


                #region Notification Setup: Task Level
                FastDriver.NotificationSetup.TaskStatus.FASelectItem("Activated");
                FastDriver.NotificationSetup.DeliveryMethod.FASelectItem("Email");

                Reports.TestStep = "Click on File Roles.";
                FastDriver.NotificationSetup.FileRoles.FAClick();

                FastDriver.SelectFBPRolesDlg.SwitchToDialogContentFrame();
                Playback.Wait(3000);
                FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Invoice To Party", 1, TableAction.Click);
                Playback.Wait(1000);

                FastDriver.SelectFBPRolesDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NotificationSetup.SwitchToContentFrame();

                Reports.TestStep = "Enter data element";
                FastDriver.NotificationSetup.SubjectLine.FASetText("^BSNAM1^");

                Reports.TestStep = "Select Designed Sender.";
                FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");

                Reports.TestStep = "Click on right direction.";
                FastDriver.NotificationSetup.RightDirectionArrow.FAClick();

                Reports.TestStep = "Enter Name for designated sender.";
                FastDriver.NotificationSetup.DesignatedSenderName.FASetText("Designated sender name");

                Reports.TestStep = "Enter Email address designated sender.";
                FastDriver.NotificationSetup.DesignatedSenderEmailAddress.FASetText("designated@firstam.com");

                Reports.TestStep = "Click on Add/Remove document.";
                FastDriver.NotificationSetup.DocumentsAddRemove.FAClick();

                Reports.TestStep = "Select a Document.";
                FastDriver.DocumentSelectionDlg.WaitForScreenLoad();

                FastDriver.DocumentSelectionDlg.Source.FASelectItem("DOCPREP Corporate Region");
                Playback.Wait(1000);

                FastDriver.DocumentSelectionDlg.TemplateType.FASelectItem("Title Reports");
                FastDriver.DocumentSelectionDlg.FindNow.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Verify ATP - Tax Search Form exists and can be selected";
                FastDriver.DocumentSelectionDlg.DocumnentSearchTable.PerformTableAction(2, "ATP - Tax Research Form", 1, TableAction.Click);
                FastDriver.DocumentSelectionDlg.Add.FAClick();
                Playback.Wait(1000);
                FastDriver.DocumentSelectionDlg.DocumentSelectionTable.PerformTableAction(2, "ATP - Tax Research Form", 1, TableAction.Click);
                FastDriver.DocumentSelectionDlg.Select.FAClick();

                Reports.TestStep = "Validate that the document is attached";
                FastDriver.NotificationSetup.SwitchToContentFrame();
                Playback.Wait(1000);
                string value = FastDriver.NotificationSetup.DocumentsTable.GetRowCount().ToString();
                Support.AreEqual("2", value);

                Reports.TestStep = "Click on Message Template Select.";
                FastDriver.NotificationSetup.Select.FAClick();

                Reports.TestStep = "Select the message template.";
                FastDriver.MessageTemplateSelectionDlg.SwitchToDialogContentFrame();
                FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(1, "PROMSG1", 1, TableAction.Click);
                Playback.Wait(1000);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();

                FastDriver.NotificationSetup.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.NotificationSetup.TaskStatus.FAGetSelectedItem().Contains("Activated").ToString());
                Support.AreEqual("True", FastDriver.NotificationSetup.DeliveryMethod.FAGetSelectedItem().Contains("Email").ToString());
                Support.AreEqual("True", FastDriver.NotificationSetup.MessageTemplate.FAGetValue().Contains("CreatedForProActiveEnhTest").ToString());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();
                FastDriver.BottomFrame.btnDone.FAClick();
                #endregion

               

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Endorsement Guarantee", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion


                #region Select Notification Attachment Candidate check box
                Reports.TestStep = "Select Notification Attachment Candidate check box";
                FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Verify error message
                Reports.TestStep = "Verify the error message thrown";
                string Message = "";
                Message = "This Document Template has been associated to a Notification,Notification Attachment Candidate cannot be de-selected.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion






            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0022_DP8175
        [TestMethod]
        [Description("Template Description Wild Card")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0022_DP8175()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Template Description Wild Card";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template entering Wild Card";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Endorsement Guarantee", "NEXTGEN*");
                #endregion

                #region Verify the templates found related to NEXTGEN
                Reports.TestStep = "Verify the templates found related to NEXTGEN";
               
                int Typerow_Count = 0;
                Typerow_Count = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FindElements(By.TagName("tr")).Count;
                if(Typerow_Count > 0)
                { 
                
                    Support.AreEqual("True","True","Templates found related to NEXTGEN");
                
                }
                else
                {
                    Support.AreEqual("True", "True", "Templates not found related to NEXTGEN");
                }
                
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0023_DP8183
        [TestMethod]
        [Description("Insert Multiple Phrases At One Time")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0023_DP8183()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Insert Multiple Phrases At One Time";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Endorsement Guarantee", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template View Button
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Click on Template View Button
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Insert Multiple Phrases
                FastDriver.DocumentEditor.InsertMultiplePhrase();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(); 
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0024_DP8184
        [TestMethod]
        [Description("Inserting the Same Phrases Many Times")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0024_DP8184()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Inserting the Same Phrases Many Times";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Endorsement Guarantee", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification");
                #endregion

                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch_Notification", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template View Button
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Click on Template View Button
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Insert Multiple Phrases
                FastDriver.DocumentEditor.InsertSamePhraseMultipleTimes();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0025_DP8188
        [TestMethod]
        [Description("Removing Template Phrases")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0025_DP8188()
        {
            try
            {
                Reports.TestDescription = "Removing Template Phrases";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Remove phrase from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.RemovePhrase.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();            
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0026_DP8189
        [TestMethod]
        [Description("'Required' Phrases")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0026_DP8189()
        {
            try
            {
                Reports.TestDescription = "'Required' Phrases";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click on Template Phrases tab
                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                #endregion

                #region Make phrase as required from the template phrases tab
                Reports.TestStep = "Create phrase from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.RequiredPhrase.FAClick();
                #endregion


                #region Verify whether the selected phrase is marked as required
                Reports.TestStep = "Verify whether the selected phrase is marked as required";
                string phraseName = FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("True",phraseName.Contains("**").ToString(),true);  

                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0027_DP8221
        [TestMethod]
        [Description("Define a Geographic Filter")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0027_DP8221()
        {
            try
            {
                Reports.TestDescription = "Define a Geographic Filter";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Search Template";
                FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
                #region Select and right click on the template. Click on View/Edit Template Option
                Reports.TestStep = "Select a Template and right click for View/Edit Template option";
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                Playback.Wait(3000);
                #endregion

                #region Click Filtering TAB 
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter 
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Verify \"Add/Remove\" button in Country and City row is enabled or disabled
                Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), false);
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.CityAddRemove.IsEnabled().ToString(), false);
                #endregion
    
                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);                             
                
                #endregion

                #region Verify \"Add/Remove\" button in Country row is enabled or disabled
                Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);                              
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a Country
                Reports.TestStep = "Click on Clear button and select a Country";
                FastDriver.CountySelectionDlg.Clear.FAClick();  
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ALAMEDA", "Select", TableAction.On);                
                FastDriver.CountySelectionDlg.Select.FAClick();        
                #endregion

                #region Verify \"Add/Remove\" button in the City row is enabled or disabled
                Reports.TestStep = "Verify \"Add/Remove\" button in the City row is enabled or disabled";
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CityAddRemove.IsEnabled().ToString(), true); 
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0028_DP8222
        [TestMethod]
        [Description("Apply Geographic Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0028_DP8222()
        {
            try
            {
                Reports.TestDescription = "Apply Geographic Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();    
                #endregion        
                
                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion
                

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);

                #endregion

                #region Verify \"Add/Remove\" button in Country row is enabled or disabled
                Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a Country
                Reports.TestStep = "Click on Clear button and select a Country";
                FastDriver.CountySelectionDlg.Clear.FAClick();
                FastDriver.CountySelectionDlg.CheckAll.FAClick();
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();                
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion
                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Navigate to the file side 
                Reports.TestStep = "Navigate to the file side";
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository Screen

                Reports.TestStep = "Navigate to Document Repository Screen";               
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
               
                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);                               
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0029_DP8223_DP8224_A
        [TestMethod]
        [Description("Define a Service Type Filter/Apply \"Title\" Service Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0029_DP8223_DP8224_A()
        {
            string entityid = "BOA";
            
            try
            {
                Reports.TestDescription = "Define a Service Type Filter/Apply \"Title\" Service Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
               // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();  
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";                
                FastDriver.GeograficFilterSelectionDlg.TitleServiveTypeCheck.FAClick();               
                #endregion


                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                //if (!FastDriver.QuickFileEntry.Escrow.Selected)
                //    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
               
                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion

                #region Navigate to File Home Page
                Reports.TestStep = "Navigate to File Home Page";
                FastDriver.FileHomepage.Open();
                #endregion

                #region Click on "Change O/O" button
                Reports.TestStep = "Click on \"Change O/O\" button";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                #endregion

                #region Select Escrow Service Type and Save
                Reports.TestStep = "Select Escrow Service Type and Save";
                FastDriver.FileHomepage.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                TempTebleDescription = "";
                TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion
                
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0030_DP8223_DP8224_B
        [TestMethod]
        [Description("Define a Service Type Filter/Apply \"Escrow\" Service Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0030_DP8223_DP8224_B()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Service Type Filter/Apply \"Escrow \" Service Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.EscrowServiveTypeCheck.FAClick();
                #endregion


                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                //if (!FastDriver.QuickFileEntry.Title.Selected)
                  //  FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion

                #region Navigate to File Home Page
                Reports.TestStep = "Navigate to File Home Page";
                FastDriver.FileHomepage.Open();
                #endregion

                #region Click on "Change O/O" button
                Reports.TestStep = "Click on \"Change O/O\" button";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                #endregion

                #region Select Escrow Service Type and Save
                Reports.TestStep = "Select Escrow Service Type and Save";
                FastDriver.FileHomepage.Title.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                TempTebleDescription = "";
                TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0031_DP8223_DP8224_C
        [TestMethod]
        [Description("Define a Service Type Filter/Apply \"Sub Escrow\" Service Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0031_DP8223_DP8224_C()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Service Type Filter/Apply \"Sub Escrow\" Service Type Filter to \"Title/Sub Escrow\" type File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.SubEscrowServiveTypeCheck.FAClick();
                #endregion


                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                   FastDriver.QuickFileEntry.Title.FAClick();
                //if (!FastDriver.QuickFileEntry.Escrow.Selected)
                //    FastDriver.QuickFileEntry.Escrow.FAClick();

                if (!FastDriver.QuickFileEntry.SubEscrow.Selected)
                    FastDriver.QuickFileEntry.SubEscrow.FAClick();

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion

                #region Navigate to File Home Page
                Reports.TestStep = "Navigate to File Home Page";
                FastDriver.FileHomepage.Open();
                #endregion

                #region Click on "Change O/O" button
                Reports.TestStep = "Click on \"Change O/O\" button";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                #endregion

                #region Select Escrow Service Type and Save
                Reports.TestStep = "Select Escrow Service Type and Save";
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                int TempTableRowCount = 0;
                TempTableRowCount = FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount();
                if (TempTableRowCount == 0)
                Support.AreEqual("True","True","No Templates Found in Template Result Table");
                
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0032_DP8223_DP8224_C1
        [TestMethod]
        [Description("Define a Service Type Filter/Apply \"Sub Escrow\" Service Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0032_DP8223_DP8224_C1()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Service Type Filter/Apply \"Sub Escrow\" Service Type Filter to \"Escrow/Sub Escrow\" type File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.SubEscrowServiveTypeCheck.FAClick();
                #endregion


                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                //if (!FastDriver.QuickFileEntry.Title.Selected)
                //    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();

                if (!FastDriver.QuickFileEntry.SubEscrow.Selected)
                    FastDriver.QuickFileEntry.SubEscrow.FAClick();

                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion

                #region Navigate to File Home Page
                Reports.TestStep = "Navigate to File Home Page";
                FastDriver.FileHomepage.Open();
                #endregion

                #region Click on "Change O/O" button
                Reports.TestStep = "Click on \"Change O/O\" button";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                #endregion

                #region Select Escrow Service Type and Save
                Reports.TestStep = "Select Escrow Service Type and Save";
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                int TempTableRowCount = 0;
                TempTableRowCount = FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount();
                if (TempTableRowCount == 0)
                    Support.AreEqual("True", "True", "No Templates Found in Template Result Table");

                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0033_DP8223_DP8224_D
        [TestMethod]
        [Description("Define a Service Type Filter/Apply All Service Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0033_DP8223_DP8224_D()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Service Type Filter/Apply All Service Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion
                
                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion
                

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0033_DP8225_DP8226
        [TestMethod]
        [Description("Define an Underwriter Filter/Apply Underwriter Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0033_DP8225_DP8226()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define an Underwriter Filter/Apply Underwriter Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select Underwriter Filter
                Reports.TestStep = "Select Underwriter Filter";
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASelectItem("First American Title Insurance Company");
                string strUnderWriter = FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAGetSelectedItem(); 
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                //FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
               
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);             
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0034_DP8227_DP8228
        [TestMethod]
        [Description("Define an Owning Office Filter/Owning Office")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0034_DP8227_DP8228()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define an Owning Office Filter/Owning Office";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick(); 
                #endregion               


                #region Select Owning Office Filter
                Reports.TestStep = "Select Owning Office Filter";
                FastDriver.GeograficFilterSelectionDlg.OwningOffice.FASelectItem("QA Sandpointe Office - Next Gen");
                string strOwningOfce = FastDriver.GeograficFilterSelectionDlg.OwningOffice.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";                
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();

               
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");  

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0035_DP8229_DP8230
        [TestMethod]
        [Description("Define a Property Type Filter/Apply Property Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0035_DP8227_DP8228()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Property Type Filter/Apply Property Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select Property Type Filter
                Reports.TestStep = "Select Property Type Filter";
                FastDriver.GeograficFilterSelectionDlg.PropertyType.FASelectItem("Single Family Residence");
                string strOwningOfce = FastDriver.GeograficFilterSelectionDlg.PropertyType.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();  

                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys(strOwningOfce);
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0036_DP8231_DP8232
        [TestMethod]
        [Description("Define a Product Filter/Apply Product Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0036_DP8231_DP8232()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Product Filter/Apply Product Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select a Product from the list box
                Reports.TestStep = "Select a Product from the list box";
                FastDriver.GeograficFilterSelectionDlg.Products.FASelectItem("ALTA Construction Loan 1992 Policy");
                string strProducts = FastDriver.GeograficFilterSelectionDlg.Products.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();              
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
               
                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
               // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                

                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0037_DP9645_DP9644
        [TestMethod]
        [Description("Define Program Type Filter/Apply Program Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0037_DP9645_DP9644()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define Program Type Filter/Apply Program Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select any Program Type from the list box
                Reports.TestStep = "Select any Program Type from the list box";
                FastDriver.NextGenDocumentPreparation.ProgramType.FASelectItem("No Program Type");
                string strProducts = FastDriver.NextGenDocumentPreparation.ProgramType.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();  

                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion

        #region REG0038_DP9646_DP9647
        [TestMethod]
        [Description("Define Search Type Filter/Apply Search Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0038_DP9646_DP9647()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define Search Type Filter/Apply Search Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select any Search Type from the list box
                Reports.TestStep = "Select any Search Type from the list box";
                FastDriver.NextGenDocumentPreparation.SearchType.FASelectItem("04-Ownership Report");
                string strProducts = FastDriver.NextGenDocumentPreparation.SearchType.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();

                
                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                //FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();

                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                //FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);

                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(1, 1, TableAction.On, "04-Ownership Report", true);
                
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad(); 


                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0039_DP8233_DP8234
        [TestMethod]
        [Description("Define a Business Segment Filter/Apply Business Segment Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0039_DP8233_DP8234()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Business Segment Filter/Apply Business Segment Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion


                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion


                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion


                #region Select any Business Segment from the list box
                Reports.TestStep = "Select any Business Segment from the list box";
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                string strProducts = FastDriver.NextGenDocumentPreparation.BusinessSegment.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();


                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();

                #endregion


                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                //FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);

                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(1, 1, TableAction.On, "04-Ownership Report", true);

                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();


                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0040_DP8235_DP8236
        [TestMethod]
        [Description("Define a Transaction Type Filter/Apply Transaction Type Filter to File Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0040_DP8235_DP8236()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Define a Transaction Type Filter/Apply Transaction Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion
                
                #region Click on Add filter
                Reports.TestStep = "Click on Add filter";
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                // FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.CheckAll.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                //#region Verify \"Add/Remove\" button in Country row is enabled or disabled
                //Reports.TestStep = "Verify \"Add/Remove\" button in Country row is enabled or disabled";
                //Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.CountyAddRemove.IsEnabled().ToString(), true);
                //#endregion

                //#region In the county row click on "Add/Remove" button
                //Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                //FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                //FastDriver.CountySelectionDlg.WaitForScreenToLoad(FastDriver.CountySelectionDlg.Select);
                //#endregion

                //#region Click on Clear button and select a Country
                //Reports.TestStep = "Click on Clear button and select a Country";
                //FastDriver.CountySelectionDlg.Clear.FAClick();
                //FastDriver.CountySelectionDlg.CheckAll.FAClick();
                //FastDriver.CountySelectionDlg.Select.FAClick();
                //#endregion


                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion
                
                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                //string strProducts = FastDriver.NextGenDocumentPreparation.BusinessSegment.FAGetSelectedItem();
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
               // FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();


                //FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();

                #endregion
                
                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                //FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);

                FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(1, 1, TableAction.On, "04-Ownership Report", true);

                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();


                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(TempDescription, TempTebleDescription, true);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0041_DP8242
        [TestMethod]
        [Description("Exclude Templates Without Filters from File Filtered Templates")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0041_DP8242()
        {
            string entityid = "BOA";

            try
            {
                Reports.TestDescription = "Exclude Templates Without Filters from File Filtered Templates";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region SearchSearch template
                Reports.TestStep = "Create Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();
                #endregion            


                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                //FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                //Reports.TestStep = "Select a Policy from the table.";
                //FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                //// FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                //FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                //FastDriver.DialogBottomFrame.ClickDone();


                //Reports.TestStep = "Select the Search instruction search type";
                //FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FASelectItemBySendingKeys("++View More");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                //FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                //FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);

                //FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(1, 1, TableAction.On, "04-Ownership Report", true);

                //FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
               // FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.QuickFileEntry.SwitchToContentFrame();
                //FastDriver.QuickFileEntry.WaitForScreenToLoad();


                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";

                int rowCount = FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount(); 
                
                if(rowCount>0 )
                Support.AreEqual("True", "True", "Template" + TempDescription + "has not found in the Filtered Templates list");
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        #endregion
        
        #region REG0042_DP10942

        [TestMethod]
        [Description("Create a New Template Type: Policy w/o Title Reports")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0001_DP10942()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Create a New Template Type: Policy w/o Title Reports";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate to NextGen Document Preparation Screen and create a Template (DP8180,DP8182)
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Escrow Phrase[ESCROW]", "Policy-NXTGN11", "Policy w/o Title Reports");
                string TempDescription = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetText();              
                #endregion
                #region Go to Template Search Tab
                Reports.TestStep = "Go to Template Search Tab";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                #endregion

                #region Go to Select \"Policy w/o Title Reports\" in Template Type Dropdown
                Reports.TestStep = "Select \"Policy w/o Title Reports\" in Template Type Dropdown";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Policy w/o Title Reports");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TempDescription);
                FastDriver.NextGenDocumentPreparation.Search.FAClick(); 
                #endregion

                #region Validate if the template is created for Policy w/o Title Reports
                Reports.TestStep = "Validate if the template is created for Policy w/o Title Reports";
                int rowCount = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetRowCount();
                if (rowCount > 0)
                    Support.AreEqual("True", "True", "Template for Policy w/o Title Reports created");
                #endregion












            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0043_US246922
        [TestMethod]
        [Description("133273 - To Verify that the system shall show the template as a Filtered Template in files where the file's first property's first address corresponds to the Geographic Filter's selections.")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0043_US133273()
        {
            
         try
            {

                Reports.TestDescription = "Define a Transaction Type Filter/Apply Transaction Type Filter to File Documents";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);


                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

            #region Login to File Side
            Reports.TestDescription = "Login to IIS site";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);
            #endregion

            #region Createfile
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            Reports.TestStep = "Select a Program Type.";
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

            //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

            FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
            Reports.TestStep = "Select a Policy from the table.";
            FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
            // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
            FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();
            Reports.TestStep = "Select the Search instruction search type";
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.SearchType.Highlight();
            FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
            FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
            FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
            FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
            FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            Playback.Wait(1000);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw new Exception("File could not be created");
            }
            #endregion

            #region Navigate to Document Repository Screen
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Click on "Template Search" button
            Reports.TestStep = "Click on \"Template Search\" button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion

            #region Search for templates using search criteria
            Reports.TestStep = "Search for templates using search criteria";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
           
            #endregion

            #region Validate the filtered template in the Template Result table
            Reports.TestStep = "Validate the filtered template in the Template Result table";
               FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
            string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction("Template Name", "BCD7", "Description", TableAction.GetText).Message;
            Support.AreEqual("Test-BCD7", TempTebleDescription, true);
                 
            #endregion
            }

         catch (Exception ex)
         {
             FailTest(GetExceptionInfo(ex));
         }


        }
        #endregion

        #region REG0044_US246923
        [TestMethod]
        [Description("133274 - To Verify that the system does not show the template as a Filtered Template in files where the file's first property's second address corresponds to the Geographic Filter's selections.")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0044_US133274()
        {

            try
            {

                Reports.TestDescription = "133274 - To Verify that the system does not show the template as a Filtered Template in files where the file's first property's second address corresponds to the Geographic Filter's selections.";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);


                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");

                //FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem(strUnderWriter);
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                // FastDriver.ProductListDlg.ProductType.FASelectItem(@"Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SearchType.Highlight();
                FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                //FastDriver.SelectInstructionsDlg.InstructionsTable.PerformTableAction(1, 1, TableAction.On, "04-Ownership Report", true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CO");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Property Tax Info Screen
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First American");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Sitka");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AA");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(5000);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
                #endregion

                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                Support.AreEqual("3", FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount().ToString(), true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }
        #endregion

        #region REG0045_US246924
        [TestMethod]
        [Description("133276 - To Verify that the system shall show the template as a Filtered Template in files where the file's Underwriter corresponds to one of the filter's selections.")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0045_US133276()
        {

            try
            {

                Reports.TestDescription = "133276 - To Verify that the system shall show the template as a Filtered Template in files where the file's Underwriter corresponds to one of the filter's selections.";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                //FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASelectItem("First American Title Insurance Company");
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItem("First American Title Insurance Company");
                FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem("Underwriter Issued Policy");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SearchType.Highlight();
                FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction("Template Name", "BCD7", "Description", TableAction.GetText).Message;
                Support.AreEqual("Test-BCD7", TempTebleDescription, true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }
        #endregion

        #region REG0046_US246925
        [TestMethod]
        [Description("133283 - To Verify that the system does not show the template as a Filtered Template in files where the file's Underwriter does not correspond to one of the filter's selections.")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0046_US133283()
        {

            try
            {

                Reports.TestDescription = "133283 - To Verify that the system does not show the template as a Filtered Template in files where the file's Underwriter does not correspond to one of the filter's selections.";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                //FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASelectItem("First American Title Insurance Company");
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItem("");
                FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem("Agent Issued Policy");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SearchType.Highlight();
                FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
                Support.AreEqual("3", FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount().ToString(), true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }
        #endregion

        #region REG0047_US246927
        [TestMethod]
        [Description("133367 - To Verify that the system makes document template available in Title only, Title + Escrow, and Title + Sub Escrow files when Title Service alone is selected in Template filter")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0047_US133367()
        {

            try
            {

                Reports.TestDescription = "133367 - To Verify that the system makes document template available in Title only, Title + Escrow, and Title + Sub Escrow files when Title Service alone is selected in Template filter";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (FastDriver.QuickFileEntry.SubEscrow.Selected)
                    FastDriver.QuickFileEntry.SubEscrow.FAClick();
                if (FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");
                FastDriver.QuickFileEntry.UnderWriterFilter.FASelectItem("Agent Issued Policy");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SearchType.Highlight();
                FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
                string TempTebleDescription = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction("Template Name", "BCD7", "Description", TableAction.GetText).Message;
                Support.AreEqual("Test-BCD7", TempTebleDescription, true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }
        #endregion

        #region REG0048_US246928
        [TestMethod]
        [Description("133368 - To Verify that the system does not makes document template available in Escrow + Sub Escrow files. when Title Service alone is selected in Template filter")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0048_US133368()
        {

            try
            {

                Reports.TestDescription = "133368 - To Verify that the system does not makes document template available in Escrow + Sub Escrow files. when Title Service alone is selected in Template filter";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                Reports.TestDescription = "Navigate to ADM site";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("Test-BCD7");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Test-BCD7", "Description", TableAction.DoubleClick);

                #endregion

                #region Click Filtering TAB
                Reports.TestStep = "Click Filtering TAB";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                #endregion

                #region Click on Edit filter
                Reports.TestStep = "Click on Edit filter";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on \"Add/Remove\" button
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.Select);
                #endregion

                #region Click on Clear button and select a State
                Reports.TestStep = "Click on Clear button and select a State";
                FastDriver.StateSelectionDlg.Clear.FAClick();
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Select "Title" service type filter
                Reports.TestStep = " Select \"Title\" service type filter";
                FastDriver.GeograficFilterSelectionDlg.TitleServiveTypeCheck.FASetCheckbox(true);
                #endregion

                #region Select any Transaction Type  from the list box
                Reports.TestStep = "Select any Transaction Type  from the list box";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                #endregion

                #region Select the mandatory fields
                Reports.TestStep = "Select the mandatory fields";
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FASetCheckbox(true);

                #endregion

                #region Save the Template
                Reports.TestStep = "Save the Template";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Login to File Side
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.SubEscrow.Selected)
                    FastDriver.QuickFileEntry.SubEscrow.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                if (FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                Reports.TestStep = "Select a Program Type.";
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem("QA Sandpointe Office - Next Gen PR: QANG Off: 1111 (12839)");
                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");

                FastDriver.QuickFileEntry.AddRemoveProducts.FAClick();
                Reports.TestStep = "Select a Policy from the table.";
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Construction Loan 1992 Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Select the Search instruction search type";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.SearchType.Highlight();
                FastDriver.QuickFileEntry.SearchType.FASelectItem("++View More...");
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(1);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Search Type");
                FastDriver.SearchTypeDialogDlg.SwitchToDialogContentFrame();
                FastDriver.SearchTypeDialogDlg.SelectionRadioButton.FASetCheckbox(true);
                FastDriver.SearchTypeDialogDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Test-BCD7");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Validate the filtered template in the Template Result table
                Reports.TestStep = "Validate the filtered template in the Template Result table";
                FastDriver.NextGenDocumentRepository.TemplatesTable.GiveFocus();
                Support.AreEqual("3", FastDriver.NextGenDocumentRepository.TemplatesTable.GetRowCount().ToString(), true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }
        #endregion


        #region Private methods
        private int regionId
        {
            get { return _regionId; }
        }
        private int officeId
        {
            get { return _officeId; }
        }

        public bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }


        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private void InsertDataElement_ErrorMessage()
        {
            try
            {
                var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine2;
                if (currentLine.DelayOnce(10).Visible() == false)
                    currentLine.DelayOnce(60);
                currentLine.FAClick();
                Keyboard.SendKeys(FAKeys.Enter);
                FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
                FastDriver.DocumentEditor.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
                FastDriver.DocumentEditor.IRInsertSearch5.DoubleClick();
                Keyboard.SendKeys(FAKeys.Enter);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer_Buyer");
                FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                #region Verify error message
                Reports.TestStep = "Verify the error message thrown";
                string Message = "";
                Message = "Data Element is invalid. Please enter valid data element";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                #endregion


                if (FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).Visible())   // 1920 * 1280
                    FastDriver.DocumentEditor.IRSave.Offset(1850, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).Visible())     // 1680 * 1050
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).Visible())     // 1280 * 1024
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).FAClick();
                else
                    Support.Fail("'Save' was not found by ImageRecognition");


                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                //FastDriver.DocumentEditor.Yes.FAClick();
                Playback.Wait(6000);

            }
            catch (Exception ex)
            {
                MasterTestClass.FailTest(MasterTestClass.GetExceptionInfo(ex));
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        #endregion



        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
