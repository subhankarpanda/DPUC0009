﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace NextGenDocPrep
{

    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class NextGen_DPUC0002 : FASTHelpers
    {
        private static int _regionId = 12837;
        private static int _officeId = 12839;
        private SilverlightSupport FALibSL;

        #region Private methods

        private void DeleteForm(string formName)
        {
            FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
            FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
            FastDriver.FormMaintenanceSummary.Delete.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
        }

        #endregion

        #region REG

        #region NextGen_DPUC0003_BAT0001
        [TestMethod]
        [DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Add a New Form; AF3: Edit the Form; AF4_AF5: Undo Check Out and Delete the Form.";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();     
                
                Reports.TestStep = "Create a Form.";
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");

                FastDriver.FormMaintenance.EnterFormUploadData(formName, true, "Creating New Form");
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Newly created form.";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.Highlight(5); 
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);    
               // FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                //Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");

               // Reports.TestStep = "Select the form and click Download";
               // FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Select the form and click View";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.View.FAClick();

                Reports.TestStep = "Change form description, then click Done";
                formName = formName + "EDIT";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FormDescriptiontxt.FASetText(formName);
                FastDriver.BottomFrame.Done();

                

                Reports.TestStep = "Verify Edited form name";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);

                Reports.TestStep = "Select the form and click Undo Check Out";
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.UndoChkout.FAClick();
                Support.AreEqual("Are you sure you wish to undo the check out of " + formName + " ? This action cannot be undone", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());

                Reports.TestStep = "Select the form and click Delete";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Deletebtn.FAClick();
                Support.AreEqual("Are you sure you wish to delete " + formName + " ? This action cannot be undone.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region NextGen_DPUC0003_REG0002
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Add a New Form; AF3: Edit the Form; AF4_AF5: Undo Check Out and Delete the Form.";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();

                Reports.TestStep = "Create a Form.";
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");

                FastDriver.FormMaintenance.EnterFormUploadData(formName, true, "Creating New Form");
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Newly created form.";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);
                // FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                //Support.AreEqual(formName, FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.GetText).Message, "Form Description");

                // Reports.TestStep = "Select the form and click Download";
                // FastDriver.FormMaintenanceSummary.FormSummaryTable.PerformTableAction(1, formName, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Download.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Close FAST application";
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Login as different user";
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();

                Reports.TestStep = "Validate form state is checked out";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                Support.AreEqual("Checked Out -" + AutoConfig.UserNameSecondary.ToUpper(), FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 0, TableAction.GetText).Message.Clean(), "Form State");

                Reports.TestStep = "Click on the form to validate the warning message";
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName, 1, TableAction.Click);
                Support.AreEqual("Document checked out by " + AutoConfig.UserNameSecondary.ToUpper(), FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Message from webpage");

                Reports.TestStep = "Create a Form.";
                string formName1 = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");

                FastDriver.FormMaintenance.EnterFormUploadData(formName1, true, "Creating New Form");
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Newly created form.";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.Click);

                Reports.TestStep = "Select the form and click Download";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.View.FAClick();
                Playback.Wait(2000);
                FastDriver.FormMaintenanceSummary.HandleOpenOrSave("Save");

                Reports.TestStep = "Replace the checked out form";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.Click);
                FastDriver.FormMaintenanceSummary.Properties.FAClick();
                FastDriver.FormMaintenance.EnterFormUploadData(formName1, true, "Replace old form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the new form name and state of form";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                Support.AreEqual(formName, FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.GetText).Message, "Form Description");
                Support.AreEqual(string.Empty, FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 3, TableAction.GetText).Message.Clean(), "Form State");

                Reports.TestStep = "Delete the form (cleanup)";
                DeleteForm(formName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region NextGen_DPUC0003_REG0003
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Add a New Form; AF3: Edit the Form; AF4_AF5: Undo Check Out and Delete the Form.";

                #region Navigate to ADM site
                Reports.TestStep = "Navigate to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();

                Reports.TestStep = "Create a Form.";
                string formName1 = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");

                FastDriver.FormMaintenance.EnterFormUploadData(formName1, true, "Creating New Form");

                Reports.TestStep = "Create second form";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();
                string formName2 = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");

                FastDriver.FormMaintenance.EnterFormUploadData(formName2, true, "Creating New Form");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate forms display order on form summary table.";
                //FastDriver.FormMaintenanceSummary.WaitForScreenToLoad(FastDriver.FormMaintenanceSummary.FormSummaryTable);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FormsTable);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.Click);
                int form1Row = FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName1, 1, TableAction.GetCell).CurrentRow;
                int form2Row = FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, formName2, 1, TableAction.GetCell).CurrentRow;
                Support.AreEqual((form1Row + 1).ToString(), form2Row.ToString());

                Reports.TestStep = "Delete the forms (cleanup)";
                DeleteForm(formName1);
                DeleteForm(formName2);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

       

        #region NextGen_DPUC0003_REG0004
        [TestMethod, DeploymentItem(@"Common\Support\GeneralForm.doc")]
        public void DPUC0003_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "DP8293  Form Description Required; DP8294  Form Description Unique; DP8300  Special Characters; DP8298  File Location Required When Uploading A Form; DP8296  MS Word Files Only; DP8301  Form Name Is Not Case Sensitive";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Form Maintenance Summary screen.";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
              //  FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();


                Reports.TestStep = "Get an exsting form description and save it for later use";
                string existingFormDescription = FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(1, 1, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Create a form without form description";
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();
                string formName = "DPUC0003FORM" + Support.RandomString("AAAAAAAAAA");
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                var fileLoc = Reports.DEPLOYDIR + @"\" + formName + ".doc";
                fileLoc = fileLoc.ToUpper();
                var invalidFileLoc = Reports.DEPLOYDIR + @"\" + formName + ".docx";
                System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", fileLoc, true);
                System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", invalidFileLoc, true);

                Reports.TestStep = "Validate warning message when form description is not entered.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please enter a Form Description.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Empty form description");
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);

                Reports.TestStep = "Enter special chracters in form description and validate warning message.";
                FastDriver.FormMaintenance.FormDesc.FASetText(@"~'!@^_{}|\[]");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Special characters");

                Reports.TestStep = "Enter a valid form description.";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);

                Reports.TestStep = "Validate warning message when file location is empty.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please select a file to upload.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "File location empty");

                Reports.TestStep = "Enter an existing form description and validate warning message";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(fileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(existingFormDescription);
                FastDriver.BottomFrame.Done();
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                Support.AreEqual("The Form Description " + existingFormDescription + " is already in use, please choose another.", FastDriver.FormMaintenance.eMessage.FAGetText(), "Form description not unique");

                Reports.TestStep = "Enter an invalid file type (.docx) and validate warning message";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(invalidFileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);
                FastDriver.BottomFrame.Done();
                Support.AreEqual("The File " + formName + ".docx is not an MS Word Document. Please Correct.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean(), "Invalid document type");

                Reports.TestStep = "Enter valid form description and file location";
                FastDriver.FormMaintenance.WaitForScreenToLoad(FastDriver.FormMaintenance.FileLocation);
                FastDriver.FormMaintenance.FileLocation.FASetText(fileLoc, false);
                FastDriver.FormMaintenance.FormDesc.FASetText(formName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the form (cleanup)";
                DeleteForm(formName);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion


        private int officeId
        {
            get { return _officeId; }
        }
        #endregion
    }
}
